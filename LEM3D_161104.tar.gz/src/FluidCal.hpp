/*
 * FluidCal.hpp
 *
 *  Created on: May 20, 2014
 *      Author: John K. W. Wong, kwjw2@cam.ac.uk
 */

#ifndef FLUIDCAL_HPP_
#define FLUIDCAL_HPP_

#include "FluidNetwork.hpp"
#include "LEM3D.hpp"
#include "Dataclass.hpp"
#include <eigen3/Eigen/Sparse>

struct PRpair {
	PRpair () {};
	PRpair (	const double &_p, const double &_r) {
		p = _p;
		r = _r;
	};
	double p;
	double r;
	bool operator< 	(	const PRpair& rhs) const { return fabs(r) < fabs(rhs.r); }
	bool operator== (	const PRpair& rhs) const { return r == rhs.r; }
	bool operator== (	const double rhs)  const { return r == rhs; }
};

class FluidCal: public FluidNetwork {
public:
	FluidCal();
	FluidCal (	const double 		_viscosity,
				const double		_initTime,
				const double        _timeStep,
				const double 		_q_tolerance,
				const double		_minApecture,
				const double		_maxIncr,
				const double		_maxDecr,
				const double		_pMinAbs,
				const double		_pMaxAbs,
				const unsigned		_DOFLimit);
	virtual ~FluidCal();
	bool calculate							(	std::pair<bool,bool>& 			qStatus,
												const unsigned					step);
	bool calculate_static					(	std::pair<bool,bool>& 			qStatus,
												const unsigned					step);
	double updatePriInjPressure               (   const double                  norm);
	bool updateCalInfo						(	std::pair<bool,bool>& 			qStatus);
	double updateP                          (   const double                    pNew);
	void setInitialArea                     (   ConnectLat*                     p_conLat);
	void setBHInitStorage                   ();
	void setNotchList                       (   const std::vector<unsigned>*    p_latList);
	std::vector<unsigned>   getLatID        ();
	std::vector<IDAndInfo>	getIDAndPressure();
	std::vector<double>		getPressure		(	const double					dummyValue);
	std::vector<double>     getLeakOff      ();
	double                  getPriInjP();
	std::vector<double>		getFlowRate		();
	void                    setP0		    (	double							pressure) {
		p0=pressure;
	}
	double  getTime							() 	{ return time; };
	bool    isPChange                       ()  { return isInjPChange; };
protected:
private:
	double						time;
	double                      timeStep;
//	double                      initTimeStep;
	double						maxIncrInUse;
	double						maxDecrInUse;
	double                      maxIncrBase;
	double                      maxDecrBase;
	double						viscosity;
	double						p0;			//Pressure at first injection point
	double						q_tolerance;
	double						normRes;
	double						pMin;
	double						pMinAbs;
	double						pMax;
	double						pMaxAbs;
	double						oldInjP;
	double                      oldTotalArea;
	double						fluidEfficieny;
	double                      initBHstorage;
	unsigned					DOFLimit;
	unsigned					nbPriNum;
	unsigned					DOFseg1,DOFseg2;
	bool						isInjPChange;
	bool                        isFirstStep;
	bool                        checkpMin;
	bool                        checkpMax;
	std::array<PRpair,2> 		iterHist;
	std::vector<unsigned>		DOFtoFNode;
	std::vector<CustomPair<unsigned,double> >       notchList;
	std::vector<unsigned>		fNodeToDOF;
	std::set<unsigned>			activeDOF;
//	std::set<unsigned>			activeConFNode;
	Eigen::VectorXd 			p;				//pressure at fluid node
	Eigen::VectorXd 			q;				//discharge at fluid node, may be modified when filling H
	Eigen::VectorXd 			qOld;			//original discharge at fluid node
	unsigned					calNodeNum;
	SpMat						H;
	std::vector<SpMat>			bH;

	std::vector<IDpair> initialize			();
	void initizeNextStep					(	unsigned						&convergeCnt,
												unsigned						&relaxStep,
												bool							&isQbounded);
	bool vertifyPlimits						();
	std::pair<bool,bool> fillQ				(	const std::vector<IDpair>		qinList,
												const unsigned					step);
	double getLeakOff                       (   const unsigned                  fNodeID);
	double getDeltaLeakOff                  (   const unsigned                  fNodeID);
	double getTotalLeakOff                  ();
	double getDeltaLeakOff 					();
	double getBHstorage                     ();
	void updateLeakOff                      ();
	void setInitLeakOff                     ();
	void fillQInitial						(	const std::vector<IDpair>		qinList);
	void enforceGlobalContinuity 			(	const double					residual,
												const double					sum_s,
												const std::vector<double>*		p_storage);
	bool applyGlobalContinuity				();
	void fillP 								();


	double getHij							(	unsigned						pipeID);
	bool fillH								();
	bool serialSolve 						(	const unsigned					minIter,
		                                    	const unsigned					maxIter,
		                                    	const double 					precision);
	bool useEigenCGSolver					(	unsigned						maxIteration,
	                                        	double							precision);
	bool sparseCholeskySolve 				();
	Eigen::VectorXd getPreCondJacobi		();
	void updatePriInjPressure				();
	void updatePriInjPressureHighOrder		(	const unsigned					timeStep);
	double priInjPressureAdjust				(	const double					pNow,
												const double					pNew);
	double highOrderPredict					(	const double					pNow,
												const double					rNow,
												const int						timeStep);
	double linearPredict					(	const double					pNow,
												const double					rNow);
	double linearPredict					();
	void updateOldP 						();
	bool updateActiveConFNode				();
	void updateOldFractureStorage			();
	void printVectors						(	const unsigned 					step,
												const bool 						isPrintp,
												const bool 						isPrintq,
												const bool 						isPrintH);

	template <typename T>
	void log								(	std::ostream*				p_file,
												const T						data);

	double  getResidual 					();
	double  getActiveTotalArea              ();
	void logPQ								(	const unsigned				step,
												const std::vector<double>	P,
												const std::vector<double>	Q);
	void logRes								(	const unsigned				step,
												const double				nowP,
												const double				newP,
												const double				normRes);
	void 	test();
};

#endif /* FLUIDCAL_HPP_ */
