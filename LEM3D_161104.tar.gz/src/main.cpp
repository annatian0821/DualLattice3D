/*
 * main.cpp
 *
 *  Created on: Oct 1, 2013
 *      Author: john
 */
#include "LEM3D.hpp"
#include "Dataclass.hpp"
#include "Input.hpp"
#include "InitCond.hpp"
#include "Statistics.hpp"
#include "Loading.hpp"
#include "GConjGrad.hpp"
#include "ProProcess.hpp"
#include "Testing.hpp"
#include "GLatRemoval.hpp"
#include "Output.hpp"
#include "MiscTools.hpp"
#include "PCG_Eigen.hpp"
#include "Tesellation.hpp"
#include "Vertices.hpp"
#include "ConnectLat.hpp"
#include "FluidNetwork.hpp"
#include "FluidCal.hpp"
#include "voro++.hh"

NodeLists nodeLists;


//time_t t = time(NULL);
//tm* timePtr = localtime(&t);
//char LogPathName[1000];

//char fileName[255]; //filename

//std::string LogPath = "/home/john/output/log/log-test.log";
//std::string ErrLogPath = "/home/john/output/log/errLog-test.log";

// sprintf(LogPathName,"/home/john/output/log/log-%02d.log",timePtr->tm_year-100);

// std::string LogPath = LogPathName;
// For log file

std::ofstream ofs;
std::ofstream errFile;

//std::ofstream ofs(LogPath, std::ios::out | std::ios::app);
//std::ofstream errFile(ErrLogPath, std::ios::out | std::ios::app);
TeeDispFile tee1(std::cout,ofs);
boost::iostreams::stream<TeeDispFile> dualOut(tee1);
TeeDispFile teeErr(std::cerr,ofs);
boost::iostreams::stream<TeeDispFile> errOut(teeErr);
TeeDispFileFile tee2(errOut,errFile);
boost::iostreams::stream<TeeDispFileFile> tripOut(tee2);

//int mainProg	(	Clock* 					p_gClock);
int hydraulicFracturing		(	Clock* 							p_gClock);
int ucs						(	Clock* 							p_gClock);
bool stableLatFluid 		(	ConnectLat*						p_conLat,
    							Vertices*						p_verti,
    							FluidCal*						p_fCal,
    							PCG_Eigen*						p_EigenPCG,
    							Loading*						p_loading,
    							RTCommand*						p_rtc,
    							Output*							p_output,
    							GLatRemoval*					p_glatRemoval,
    							bool&							isStable,
    							bool& 							isRunTimeStop,
    							std::pair<bool,bool>& 			fluidStatus,
    							unsigned&						relaxStep,
    							unsigned&						totalStep,
    							const double					time,
    							const unsigned					maxIter,
								const unsigned					minLatTolerance);

int main (int argc, char** argv) {
    if(argc != 2) {
        std::cerr << "Incorrect number of arguments" << std::endl;
        std::cerr << "[USAGE:] ./lem /path/to/inputFile/inputFile.txt" << std::endl;
        std::exit(EXIT_FAILURE);
    }
    Clock* 					p_gClock		= new Clock();
    Input*					p_input			= new Input();
    p_input         -> initLogFile ();
    p_input         -> configFile(argv);
    dualOut << "**************************************************************************" << std::endl;
    dualOut << "*****************************START OF PROGRAM*****************************" << std::endl;
    dualOut << "**************************************************************************" << std::endl;
    dualOut << "Program Staring time = " << p_gClock -> getDateAndTime() << std::endl;
    p_gClock 		-> start("Global");
    unsigned status = 0;
    if (p_input -> isRead) {
        delete	p_input;
        if (ProblemID==0) {
            ucs(p_gClock);
        }
        if ((ProblemID==1)||(ProblemID==2)) {
            hydraulicFracturing (p_gClock);
        }
        if (ProblemID==999) {
            status = ucs(p_gClock);
        }
        if (ProblemID==9999) {
            status = hydraulicFracturing (p_gClock);
        }
        if (status == 0) {
            dualOut << "Program terminated successfully..." << std::endl;
        } else if (status == 1) {
            dualOut << "Program terminated because of unstable model..." << std::endl;
        } else if (status ==3) {
            dualOut << "Program terminated because of specified totalStep is reached..." << std::endl;
        } else if (status == 4) {
            dualOut << "Program terminated because of specified relaxStep is reached..." << std::endl;
        }
        dualOut << "Program ending time = " << p_gClock -> getDateAndTime() << std::endl;
        dualOut << "**************************************************************************" << std::endl;
        dualOut << "******************************END OF PROGRAM******************************" << std::endl;
        dualOut << "**************************************************************************" << std::endl;
        p_gClock			-> get();
    }
    else {
        dualOut << "Cannot read input file, program stop..." << std::endl;
    }
    delete		p_gClock;
    return 0;
}


int ucs						(	Clock* 					p_gClock)
{
    unsigned runStatus = 0;
	RTCommand*					p_rtc 			= new RTCommand (RunTimeCommendFile);
	Vertices*					p_verti			= new Vertices();
	ConnectLat*					p_conLat		= new ConnectLat(0.0);
	Output*						p_output		= new Output(OutputFolder,OutputFilePrefix);
	unsigned					maxCoordNo = 0;
	VoroTesell*					p_voro 			= new VoroTesell();
	p_voro -> generate(1.0*UnitLength,ScaleBoundary,ScaleOuterLength,&maxCoordNo,p_verti);
	std::vector<unsigned>*      p_pxCrackLatList= new std::vector<unsigned> (p_voro -> getPreExCrackLatID ());
	std::vector<unsigned>       weakPlaneLatList= p_voro -> getWeakPlaneLatID ();
	std::array<unsigned,2> 		pxCrackPerimeterNum = p_voro->getPxCrackPerimeterNum();
	Statistics*					p_stat 			= new Statistics(OutputSubFolder,OutputFilePrefix,maxCoordNo,
	                                                    2*p_pxCrackLatList->size(),p_voro->getRefineNode());
	if (GeometryID==2) {
	    p_stat      -> setCrackMonthLatList (0.05*Nx*UnitLength,p_pxCrackLatList);
	}
	p_stat		-> writeInLatAll(2*p_pxCrackLatList->size(),0,100,p_conLat);

	delete 		p_voro;
	p_output	-> writeOuterBox();
	p_output	-> writeInnerBox();

	GLatRemoval*		p_glatRemoval	= new GLatRemoval(1e-4);
	InitCond*			p_initCond 		= new InitCond(p_glatRemoval);
	PCG_Eigen*			p_EigenPCG		= new PCG_Eigen(maxCoordNo,150000);
	p_initCond 	-> setInitCond	(p_conLat,p_verti,p_EigenPCG,p_pxCrackLatList,pxCrackPerimeterNum,maxCoordNo);
	delete		p_pxCrackLatList;

	if (false) {
	    p_output                    -> writeLatAndNetwork (0,InitForce,p_conLat,p_verti,p_EigenPCG);
	    p_stat                      -> writeStress(&weakPlaneLatList,-InitStress[2],0,0);
	    p_stat                      -> writeLatStress (InitStress[2],0,p_conLat,p_EigenPCG);
	    p_stat                      -> writelatPolar (60,0,InitStress[2],p_conLat,p_EigenPCG);
	    p_stat                      -> writelatPolar (60,3,0,InitStress[2],p_conLat,p_EigenPCG);
	    p_stat                      -> fillLatPriDirList (60,0);
	}
	if (ProblemID==999) {
	//      p_output                    -> writeRawNode(totalStep);
	//      p_output                    -> writeRawLattice(p_EigenPCG,totalStep);
	        p_output                    -> writeLatAndNetwork (0,InitForce,p_conLat,p_verti,p_EigenPCG);
	        p_stat                      -> writeWeakPlaneStress (p_conLat,p_EigenPCG,&weakPlaneLatList,InitStress[2],0);
	        p_stat                      -> writeStressStrain  (InitStress[2],0);
	        p_stat                      -> fillLatPriDirList (60,0);
	        p_stat                      -> writeStress(&weakPlaneLatList,-InitStress[2],0,0);
	        p_stat                      -> writeLatStress (InitStress[2],0,p_conLat,p_EigenPCG);
	        p_stat                      -> writelatPolar (180,0,InitStress[2],p_conLat,p_EigenPCG);
	        p_stat                      -> writelatPolar (180,9,0,InitStress[2],p_conLat,p_EigenPCG);
	//      p_stat                      -> writeStressStrain  (2,2,InitForce,0);
	//      p_stat                      -> writeStressStrain  (1,1,InitForce,0);
	//      p_stat                      -> writeStressStrain  (0,0,InitForce,0);
	//      p_stat                      -> writeStress(&weakPlaneLatList,p_loading->getSumF(),totalStep,totalStep);
	//      p_stat                      -> writeLatStress (p_loading->getSumF(),totalStep,p_conLat,p_EigenPCG);
	        return 0;
	}
/*	if (ProblemID==999) {
	    return 0;
	}*/
	GLatForce*			p_glatForce 	= new GLatForce();
	FailStats*			p_fStats 		= new FailStats(OutputSubFolder,OutputFilePrefix,maxCoordNo);
	omp_set_num_threads(ThreadNumUsed);
	PreCondConjGrad*	p_customPCG 	= new PreCondConjGrad();
	p_glatRemoval		-> setRecord(true);
	Loading*			p_loading		= new Loading(LoadIncrFactor,LoadDecrFactor);

	bool 				isRunTimeStop 	= false;

	unsigned				relaxStep = 0,totalStep = 0;
	bool					relaxCheck 	= true;
	bool					isStable	= true;
	double					maxNorm 	= Huge;
	p_output            -> writeRestrain();
//	p_conLat					-> swapGroupFrontBack();
	const unsigned 			loadDir = LoadDir;
	if (DispControl) {
	    p_loading                   -> initialDisp    (LoadFace,loadDir,InitForce);
	} else {
	    p_loading					-> initLoad(InitForce,LoadFace,loadDir);
	}
//	p_loading                   -> outputForceNodes (Face6);
	isStable = p_EigenPCG 		-> solve(totalStep,true,Use_CompactStiffnessMatrix);
	if (!isStable) {
		tripOut << "***Model unstable, quit calculation!***" << std::endl;
		runStatus = 1;
		p_output		-> writeLatAndNetwork (totalStep,InitForce,p_conLat,p_verti,p_EigenPCG);
		p_fStats 		-> write (totalStep+1,30);
		return 1;
	}

//	p_output                    -> writeConstrain ();
	p_conLat					-> setLogOffset(true);
//	p_stat						-> writeStress(&weakPlaneLatList,p_loading->getSumF(),0,0.0);
	EnergyCal*       			p_eCal = new EnergyCal();
	p_eCal                      -> fillForceNodeList (LoadFace,loadDir);
//	p_glatRemoval               -> checkAllLatticeSM (p_EigenPCG,p_conLat);
	unsigned rmLatNum = 0;
	unsigned loadCnt = 0;
	for (unsigned loadStep = 0; loadStep < MaxLoadStep; loadStep++) {
		relaxStep = 0;
		relaxCheck = true;
		tripOut << "-------------------LoadStep " << loadStep << " -------------------" << std::endl;
		double sumF;
		do {
			tripOut << "--------RelaxStep " << relaxStep << "--------TotalStep " << totalStep <<" --------" << std::endl;
			p_rtc->update ();
			isRunTimeStop = p_rtc->isStop();
			if (isRunTimeStop) {
				break;
			}
			if (Use_ReconnectLattice) {
			    p_initCond		-> stableLat (p_conLat,p_verti,p_EigenPCG,isStable,relaxStep,totalStep,10,20);
			} else {
			    isStable = p_EigenPCG       -> solve(totalStep,true,Use_CompactStiffnessMatrix);
			    totalStep++;
			}
			if (!isStable) {
			    break;
			}
			if (DispControl) {
			    sumF = p_loading-> getFacePressure(LoadFace,loadDir);
			    p_loading                   -> setConForceZero();
			} else {
			    sumF = p_loading->getSumF();
			}
			p_stat                      -> writeStressStrain    (sumF,loadCnt);
			p_stat						-> writeStressStrain	(2,2,sumF,loadCnt);
			p_stat						-> writeStressStrain	(1,1,sumF,loadCnt);
			p_stat						-> writeStressStrain	(0,0,sumF,loadCnt);
			p_gClock->get();
			if ((CrackRadius>Tiny)&&(ProblemID==0)) {
			    p_conLat                    -> logFractureVol (sumF,loadCnt);
			}
			if (GeometryID==2) {
			    p_stat                      -> writeCrackMouthDispHist(sumF);
			}
			p_eCal                      -> record();
			rmLatNum = p_glatRemoval 	-> remove	(p_conLat,p_verti,p_fStats,p_EigenPCG,p_eCal,
			                                            loadCnt,0.0,&maxNorm,MaxPerStep_BrokenLattice);
			if (rmLatNum) {
			    isStable = p_EigenPCG       -> solve(loadCnt,true,Use_CompactStiffnessMatrix);
			}
			p_stat                      -> writeLatClusterAgg (p_conLat,loadCnt);
            p_eCal -> accumulate();

			std::cout << "loadCnt = " << loadCnt << std::endl;
			if (loadCnt%SampleRate==0) {
//			if (loadStep%SampleRate==0) {
//			    p_glatRemoval               -> checkAllLatticeSM (p_EigenPCG,p_conLat);
//			    p_EigenPCG -> testSM();
//			    p_output    -> writeRawNode(totalStep);
//			    p_output    -> writeRawLattice(p_EigenPCG,totalStep);
			    p_output    -> writeLatAndNetwork (loadCnt,sumF,p_conLat,p_verti,p_EigenPCG);
//			    p_output    -> writeStress (totalStep);
//			    p_output	-> writeLatAxesAll();
			    p_fStats    -> write (loadCnt,30);
			    p_stat      -> writeWeakPlaneStress (p_conLat,p_EigenPCG,&weakPlaneLatList,sumF,loadCnt);
			    p_stat      -> writeLatCluster (p_conLat,100,loadCnt);
			    p_stat      -> writelatPolar (180,loadCnt,sumF,p_conLat,p_EigenPCG);
			    p_stat      -> writelatPolar (180,5,loadCnt,sumF,p_conLat,p_EigenPCG);
			    p_stat      -> writeFailLatPolar (180,p_conLat->getAllGroupVec(),loadCnt,sumF,"all",p_EigenPCG);
			    p_stat      -> writeFailLatPolar (180,p_conLat->getAllLat(0),loadCnt,sumF,"tension",p_EigenPCG);
			    p_stat      -> writeFailLatPolar (60,p_conLat->getAllLat(1),loadCnt,sumF,"shear",p_EigenPCG);
			    p_stat      -> writeFailLatPolar (60,p_conLat->getReConLat(),loadCnt,sumF,"reCon",p_EigenPCG);
			    p_stat      -> writeFailLatPolar (60,p_conLat->getDisConLat(),loadCnt,sumF,"disCon",p_EigenPCG);
			    p_stat      -> fillLatPriDirList (60,loadCnt);
			    p_stat      -> writeStress(&weakPlaneLatList,-sumF,loadCnt,0);
			    p_stat      -> writeLatStress (sumF,loadCnt,p_conLat,p_EigenPCG);
/*			    if (!weakPlaneLatList.empty()) {
			        p_stat      -> writeStress(&weakPlaneLatList,p_loading->getSumF(),totalStep,totalStep);
			    }*/
//			    loadCnt -= SampleRate;
			}
			if (rmLatNum == 0) {
			    if (DispControl) {
			        p_loading   -> addLoad  (maxNorm);
			    } else {
			        p_loading   -> addLoad  (maxNorm,LoadFace,loadDir);
			    }
			    p_eCal -> compute (loadCnt,sumF);
			    loadCnt++;
			} else {
			    if (DispControl) {
			        p_loading   -> reduceLoad   (maxNorm);
			    } else {
				    p_loading	-> reduceLoad	(maxNorm,LoadFace,loadDir);
			    }
				p_conLat 	-> logConOffset (loadCnt,p_verti);
				p_conLat 	-> logOffset (loadCnt);
				loadCnt++;
			}
//			p_loading		-> logSumF (totalStep);
			relaxCheck = ((rmLatNum>0) && (relaxStep < MaxRelaxStep) && (totalStep < MaxTotalStep));
		} while (relaxCheck);
		if (!isStable) {
			tripOut << "***LEM Model unstable, quit calculation!***" << std::endl;
//			p_glatRemoval               -> checkAllLatticeSM (p_EigenPCG,p_conLat);
//			p_EigenPCG -> testSM();
			p_output	-> writeLatAndNetwork (loadCnt,sumF,p_conLat,p_verti,p_EigenPCG);
//			p_output	-> writeLatAxesAll();
			p_fStats 	-> write (loadCnt,30);
			runStatus = 1;
			break;
		}
		if (isRunTimeStop) {
		    p_output    -> writeLatAndNetwork (loadCnt,sumF,p_conLat,p_verti,p_EigenPCG);
		//  p_output    -> writeStress (totalStep);
		    p_fStats    -> write (loadCnt,30);
		    runStatus = 2;
		    break;
		}
		if (totalStep >= MaxTotalStep) {
			dualOut << "No of step reaches the specified maximum, calculation stop!" << std::endl;
			runStatus = 3;
			break;
		}
		if (relaxStep >= MaxRelaxStep) {
		    tripOut << "No of relax step reach the specified maximum = " << MaxRelaxStep << " calculation stop!" << std::endl;
		    runStatus = 4;
		}
	}

	delete					p_initCond;
	delete					p_rtc;
	delete					p_output;
	delete					p_fStats;
	delete					p_glatForce;
	delete					p_stat;
	delete					p_loading;
	delete					p_glatRemoval;
	delete					p_EigenPCG;
	delete					p_customPCG;
	delete					p_verti;
	delete					p_conLat;
	delete                  p_eCal;
	delete[] 				OutputFolder;
	delete[]				OutputFilePrefix;

	return runStatus;
}

int hydraulicFracturing		(	Clock* 					p_gClock)
{
    unsigned runStatus = 0;
	RTCommand*					p_rtc 			= new RTCommand (RunTimeCommendFile);
	Vertices*					p_verti			= new Vertices();
	ConnectLat*					p_conLat		= new ConnectLat(MinApecture);
	Output*						p_output		= new Output(OutputFolder,OutputFilePrefix);
	unsigned	maxCoordNo = 0;
	VoroTesell*	p_voro = new VoroTesell();
	p_voro -> generate(1.0*UnitLength,ScaleBoundary,ScaleOuterLength,&maxCoordNo,p_verti);
	std::vector<unsigned>*      p_pxCrackLatList= new std::vector<unsigned> (p_voro -> getPreExCrackLatID ());
	std::vector<unsigned>*      p_boreHoleNodeList = new std::vector<unsigned> (p_voro -> getBoreHoleNodeList ());
	std::vector<unsigned>       weakPlaneLatList= p_voro -> getWeakPlaneLatID ();
//	p_output    -> writeAllFailSurface(p_verti);
	std::array<unsigned,2> pxCrackPerimeterNum = p_voro->getPxCrackPerimeterNum();
	Statistics*	p_stat = new Statistics(OutputSubFolder,OutputFilePrefix,maxCoordNo,
	                                    2*pxCrackPerimeterNum.size(),p_voro->getRefineNode());
	p_stat		-> writeInLatAll(2*p_pxCrackLatList->size(),0,100,p_conLat);
	delete 		p_voro;
	p_output	-> writeOuterBox();
	p_output	-> writeInnerBox();
	p_stat 		-> compute(30);
	const double 		minP = std::max(1.15*InitStress[2],0.0);//1.1*std::min(std::min(InitStress[0],InitStress[1]),InitStress[2]);
    FluidCal*			p_fCal			= new FluidCal(Viscosity,InitTime,TimePerStep,
                                                1e-4,MinApecture,LoadIncrFactor,LoadDecrFactor,minP,MaxPressure,25000);
    GLatRemoval*		p_glatRemoval	= new GLatRemoval(MinApecture);
	InitCond*			p_initCond 		= new InitCond(p_glatRemoval);
	PCG_Eigen*			p_EigenPCG		= new PCG_Eigen(maxCoordNo,20000);
	p_initCond      -> setBoreHoleNodeList (p_boreHoleNodeList);
//	p_glatRemoval   -> setBHLatList (&weakPlaneLatList);
	p_glatRemoval   -> setNonReConLatList (p_pxCrackLatList);

	p_initCond 	    -> setInitCond	(p_conLat,p_glatRemoval,p_verti,p_fCal,p_EigenPCG,
									p_pxCrackLatList,pxCrackPerimeterNum,minP,maxCoordNo);
	delete		p_pxCrackLatList;
	delete      p_boreHoleNodeList;
	GLatForce*			p_glatForce = new GLatForce();
	FailStats*			p_fStats 	= new FailStats(OutputSubFolder,OutputFilePrefix,maxCoordNo);
	Testing*			p_test		= new Testing(Face6,OutputSubFolder,OutputFilePrefix);
	omp_set_num_threads(ThreadNumUsed);
	PreCondConjGrad*	p_customPCG 	= new PreCondConjGrad();
	p_glatRemoval		-> setRecord(true);
	Loading*			p_loading		= new Loading(LoadIncrFactor,LoadDecrFactor);
	bool isRunTimeStop = false;
	//First bool check fluid calculation convergence, second bool check whether fluid calculation is stable or not
	std::pair<bool,bool> 			fluidStatus(false,false);
	unsigned				relaxStep = 0,totalStep = 0;
	bool					relaxCheck 			= true;
	bool					isStable			= true;
	double					maxNorm 			= Huge;

//	p_conLat					-> swapGroupFrontBack();
	if (ProblemID==2) {
//	if (true) {
	    p_fCal      ->  setInitialList(p_conLat);
	}
	p_conLat					-> setLogOffset(true);
	p_loading					-> initLoad(InitForce,p_conLat,p_fCal);
	p_fCal                      -> updateP(InitForce);
	isStable = p_EigenPCG 		-> solve(totalStep,true,Use_CompactStiffnessMatrix);
	p_stat						-> writeStress(&weakPlaneLatList,p_fCal->getPriInjP(),0,0.0);

	EnergyCal*       p_eCal = new EnergyCal();
	unsigned rmLatAcc = 0;
	double time = 0.0;
	unsigned rmLatNum = 0;


	if (ProblemID==2) {
	    std::vector<unsigned>   fNetwork = p_conLat->getGroup(0);
	    unsigned initFNodeNum = fNetwork.size();
        do {
            dualOut << "Search for breakdown pressure..." << std::endl;
            rmLatNum = p_glatRemoval    -> remove   (p_conLat,p_verti,p_fStats,p_EigenPCG,p_eCal,
                                                     totalStep,time,&maxNorm,MaxPerStep_BrokenLattice);
            if (false) {
                p_loading                   -> initLoad(p_fCal-> updatePriInjPressure(maxNorm),p_conLat,p_fCal);
                fNetwork = p_conLat->getGroup(0);
            }
            isStable = p_EigenPCG       -> solve(totalStep,true,Use_CompactStiffnessMatrix);
            if (Use_FullPlasticModel) {
                p_glatRemoval   -> updateReConLatShearStiffness  (p_conLat,p_EigenPCG,p_verti,ReConRatio,totalStep,time);
            } else if (Use_FrictionModel) {
                p_glatRemoval   -> updateReConLatShearStiffness  (p_conLat,p_EigenPCG,p_verti,totalStep,time);
            }
            totalStep++;
            if (false) {
                p_output    -> writeNodeAndLattice(totalStep,p_EigenPCG);
                p_output    -> writeFailNetwork(totalStep,p_conLat,p_verti,p_EigenPCG);
            }
//        } while (fNetwork.size()<=initFNodeNum);
        } while (rmLatNum!=0);
        dualOut << "Finish searching for breakdown pressure" << std::endl;
        p_fCal      ->  setBHInitStorage();
        if (GeometryID==4) {
            p_fCal      ->  setNotchList(&weakPlaneLatList);
        }
	}
	p_fCal      -> setInitialArea(p_conLat);
	p_loading   -> initLoad(InitForce,p_conLat,p_fCal);
    if (true) {
        p_output    -> writeLatAndNetwork(0,1.0,p_conLat,p_verti,p_EigenPCG);
//        p_output    -> writeNodeAndLattice(0,p_EigenPCG);
//        p_output    -> writeFailNetwork(0,p_conLat,p_verti,p_EigenPCG);
        p_stat      -> writeLatCluster (p_conLat,100,0);
        double minR = avgD/(std::min(std::min(UnitLength*Nx,UnitLength*Ny),UnitLength*Nz));
        if (((GeometryID==0)||(GeometryID==3))&&(CrackRadius>minR)) {
            p_stat      -> writeRLatStats (p_conLat,p_EigenPCG,InitForce,0);
        }

        p_stat      -> writeStress(&weakPlaneLatList,p_conLat,1.0,totalStep,time);
        p_stat      -> writeWeakPlaneStress (p_conLat,p_EigenPCG,&weakPlaneLatList,InitForce,0);
        p_stat      -> writelatPolar(180,0,1.0,p_conLat,p_EigenPCG);
        p_stat      -> writelatPolar(180,5,0,1.0,p_conLat,p_EigenPCG);
        p_stat      -> writeFailLatPolar (180,p_conLat->getAllGroupVec(),totalStep,1.0,"all",p_EigenPCG);
        p_stat      -> writeFailLatPolar (180,p_conLat->getAllLat(0),totalStep,1.0,"tension",p_EigenPCG);
        p_stat      -> writeFailLatPolar (60,p_conLat->getAllLat(1),totalStep,1.0,"shear",p_EigenPCG);
        p_stat      -> writeFailLatPolar (180,p_conLat->getReConLat(),totalStep,1.0,"reCon",p_EigenPCG);
        p_stat      -> writeFailLatPolar (180,p_conLat->getDisConLat(),totalStep,1.0,"disCon",p_EigenPCG);
        p_stat      -> fillLatPriDirList (60,totalStep);

//      p_output    -> writeMSplot(0,p_conLat,p_verti);
//      p_output    -> writeLatAxes(0,p_conLat);
//      p_output    -> writeIntersect(0,p_conLat);
    }
	for (unsigned timeStep = 0; timeStep <MaxLoadStep; timeStep++) {
		relaxStep = 0;
		relaxCheck = true;
		time = p_fCal->getTime();
		tripOut << "-------------------TimeStep " << timeStep
				<< ", time = " << time << " -------------------" << std::endl;
		if ((fluidStatus.first)&&(timeStep!=0)) {
			do {
			    p_eCal->record(p_fCal);
				rmLatNum = p_glatRemoval 	-> remove	(p_conLat,p_verti,p_fStats,p_EigenPCG,p_eCal,
														totalStep,time,&maxNorm,MaxPerStep_BrokenLattice);
				isStable = p_EigenPCG       -> solve(totalStep,true,Use_CompactStiffnessMatrix);
				p_eCal->accumulate();
				if (Use_ReconnectLattice) {
				    p_initCond				-> stableLat (p_conLat,p_verti,p_EigenPCG,isStable,relaxStep,totalStep,10,20);
				}
				isRunTimeStop = p_rtc		-> isStop();
				p_glatForce                 -> calculate();
				p_rtc->update ();
				rmLatAcc += rmLatNum;
				relaxStep++;
			} while ((rmLatNum>0) && isStable && !isRunTimeStop);
			p_stat                      -> writeLatClusterAgg (p_conLat,timeStep);
			if ((isStable)&&(!isRunTimeStop)&&(rmLatAcc>0)) {
			    p_eCal-> compute (time);
			}
			fluidStatus.first = fluidStatus.second = false;
			dualOut << "Total lattice removed in this time step = " << rmLatAcc << std::endl;
			relaxStep = 0;
		}
		if (false) {
            p_loading                   -> initLoad(p_fCal->getPriInjP(),p_conLat,p_fCal);
            isStable = p_EigenPCG       -> solve(totalStep,true,Use_CompactStiffnessMatrix);
            if (Use_ReconnectLattice) {
                p_glatRemoval   -> reConnectLat(p_conLat,p_EigenPCG,MaxPerStep_BrokenLattice);
                p_glatRemoval   -> disConnectLat(p_verti,p_conLat,p_EigenPCG,totalStep,time,MaxPerStep_BrokenLattice);
            }
            relaxStep++;
            totalStep++;
		}
		while (relaxCheck) {
			tripOut << "-------------------TotalStep " << totalStep << "-------------------" << std::endl;
			maxNorm = 0.;
			stableLatFluid (p_conLat,p_verti,p_fCal,p_EigenPCG,p_loading,p_rtc,p_output,p_glatRemoval,
							isStable,isRunTimeStop,fluidStatus,relaxStep,totalStep,time,5,20);
			dualOut << "Step = " << timeStep << " relaxStep = " << relaxStep << " totalStep = " << totalStep << " maxNorm = " << maxNorm
					<< " deltaF = " << p_loading->getDeltaF() << " sumF = " << p_loading->getSumF() << std::endl;
			p_gClock->get();
			isRunTimeStop = p_rtc->isStop();
			p_rtc->update ();
			relaxCheck = (isStable && (relaxStep < MaxRelaxStep) && (totalStep < MaxTotalStep)
							&&(!isRunTimeStop)&&(!fluidStatus.first)&&(fluidStatus.second));
		}
		if (!isStable) {
			tripOut << "***LEM Model unstable, quit calculation!***" << std::endl;
			p_output	-> writeAll (totalStep,1.0,p_fCal,p_conLat,p_verti,p_EigenPCG);
			p_fStats 	-> write (timeStep+1,30);
			runStatus = 1;
			break;
		}
		if (totalStep >= MaxTotalStep) {
			dualOut << "No of step reaches the specified maximum, calculation stop!" << std::endl;
			std::pair<bool,bool>         qStatus(true,true);
			p_fCal  -> updateCalInfo(qStatus);
			runStatus = 3;
			break;
		}
		if (relaxStep >= MaxRelaxStep) {
		    dualOut << "The max no of relaxStep has been reach, proceed to next step" << std::endl;
		}
		if (!fluidStatus.second) {
			tripOut << "Fluid calculation unstable, calculation stop!" << std::endl;
			p_output	-> writeAll (totalStep,1.0, p_fCal,p_conLat,p_verti,p_EigenPCG);
			p_fStats 	-> write (totalStep,30);
			break;
		}
		p_conLat 	-> logFLat (time,rmLatAcc);
		p_conLat 	-> logConOffset (time,p_verti);
		p_conLat 	-> logOffset (time);
		rmLatAcc =0;
		if (isRunTimeStop) {
			p_glatForce	-> calculate ();
			p_output	-> writeAll (totalStep,1.0,p_fCal,p_conLat,p_verti,p_EigenPCG);
			p_fStats 	-> write (totalStep,30);
			runStatus = 2;
			break;
		}
		if ((timeStep+1)%SampleRate==0) {
			p_output	-> writeAll (timeStep+1,1.0,p_fCal,p_conLat,p_verti,p_EigenPCG);
//			p_fStats 	-> write (timeStep+1,30);
			double minR = avgD/(std::min(std::min(UnitLength*Nx,UnitLength*Ny),UnitLength*Nz));
			if (((GeometryID==0)||(GeometryID==3))&&(CrackRadius>minR)) {
			    p_stat      -> writeRLatStats (p_conLat,p_EigenPCG,p_fCal->getPriInjP(),timeStep);
			}
//			p_stat		-> writeStress(&weakPlaneLatList,1.0,timeStep,time);
			p_stat      -> writeStress(&weakPlaneLatList,p_conLat,1.0,timeStep,time);
			p_stat      -> writeWeakPlaneStress (p_conLat,p_EigenPCG,&weakPlaneLatList,p_fCal->getPriInjP(),timeStep);
			p_fCal      -> printConnectivity(timeStep);
			p_stat      -> writeLatCluster   (p_conLat,100,timeStep);
			p_stat      -> writelatPolar     (180,timeStep,1.0,p_conLat,p_EigenPCG);
			p_stat      -> writelatPolar     (180,3,timeStep,1.0,p_conLat,p_EigenPCG);
			p_stat      -> writeFailLatPolar (180,p_conLat->getAllGroupVec(),timeStep,1.0,"all",p_EigenPCG);
			p_stat      -> writeFailLatPolar (180,p_conLat->getAllLat(0),timeStep,1.0,"tension",p_EigenPCG);
			p_stat      -> writeFailLatPolar (60,p_conLat->getAllLat(1),timeStep,1.0,"shear",p_EigenPCG);
			p_stat      -> writeFailLatPolar (60,p_conLat->getReConLat(),timeStep,1.0,"reCon",p_EigenPCG);
			p_stat      -> writeFailLatPolar (60,p_conLat->getDisConLat(),timeStep,1.0,"disCon",p_EigenPCG);
			p_stat      -> fillLatPriDirList (60,timeStep);
		}
	}
	delete					p_initCond;
	delete					p_rtc;
	delete					p_output;
	delete					p_fStats;
	delete					p_fCal;
	delete					p_glatForce;
	delete					p_stat;
	delete					p_loading;
	delete					p_glatRemoval;
	delete					p_EigenPCG;
	delete					p_customPCG;
	delete					p_test;
	delete					p_verti;
	delete					p_conLat;
	delete                  p_eCal;
	delete[] 				OutputFolder;
	delete[]				OutputFilePrefix;
	return runStatus;
}

bool stableLatFluid			 				(	ConnectLat*						p_conLat,
    											Vertices*						p_verti,
    											FluidCal*						p_fCal,
    											PCG_Eigen*						p_EigenPCG,
    											Loading*						p_loading,
    											RTCommand*						p_rtc,
    											Output*							p_output,
    											GLatRemoval*					p_glatRemoval,
    											bool&							isStable,
    											bool& 							isRunTimeStop,
    											std::pair<bool,bool>& 			fluidStatus,
    											unsigned&						relaxStep,
    											unsigned&						totalStep,
    											const double					time,
    											const unsigned					maxIter,
    											const unsigned					minLatTolerance)
{
	const unsigned minLatChangeTol = 2;
	unsigned disConCnt = 0,reConCnt = 0;
	unsigned i = 0;
	unsigned oldDisConCnt = tLatticeNum, oldReConCnt = tLatticeNum;
	static std::pair<bool,bool> 		qStatus(false,false);
	tripOut << "-------------------Start Stabilizing Fluid-Lattice Modelling-------------------" << std::endl;
	dualOut << "qStatus.first, qStatus.second = " << qStatus.first << "," << qStatus.second << std::endl;
	if ((p_fCal->isPChange())&&(Use_CubicFlow)) {
	    p_loading                   -> initLoad(p_fCal->getPriInjP(),p_conLat,p_fCal);
	    isStable = p_EigenPCG       -> solve(totalStep,true,Use_CompactStiffnessMatrix);
	    if (Use_FullPlasticModel) {
	        p_glatRemoval   -> updateReConLatShearStiffness  (p_conLat,p_EigenPCG,p_verti,ReConRatio,totalStep,time);
	    } else if (Use_FrictionModel) {
	        p_glatRemoval   -> updateReConLatShearStiffness  (p_conLat,p_EigenPCG,p_verti,totalStep,time);
	    }
	}
	p_fCal						-> updateFluidNetwork(p_verti,p_conLat,time);
	//CHANGED
	if (Use_CubicFlow) {
	    fluidStatus.second = p_fCal -> calculate(qStatus,totalStep);
	} else {
	    fluidStatus.second = p_fCal	-> calculate_static(qStatus,totalStep);
	}
	if (!fluidStatus.second) {
		tripOut << "[stableLatFluid] - Fluid model unstable, quit calculation" << std::endl;
		return false;
	}
	p_loading 					-> applyFluidPressure(p_fCal,p_conLat);
	do {
		isRunTimeStop = p_rtc->isStop();
		if (isRunTimeStop) {
			return false;
		}
		p_rtc->update ();
		isStable = p_EigenPCG 		-> solve(totalStep,true,Use_CompactStiffnessMatrix);
		if (!isStable) {
			tripOut << "[stableLatFluid] - Lattice model unstable, quit calculation" << std::endl;
			return false;
		}
		if (Use_ReconnectLattice) {
		    oldReConCnt = reConCnt;
		    reConCnt  = p_glatRemoval 	-> reConnectLat(p_conLat,p_EigenPCG,MaxPerStep_BrokenLattice);
		    oldDisConCnt = disConCnt;
		    disConCnt = p_glatRemoval	-> disConnectLat(p_verti,p_conLat,p_EigenPCG,totalStep,time,MaxPerStep_BrokenLattice);
		    if (Use_FullPlasticModel) {
		        p_glatRemoval   -> updateReConLatShearStiffness  (p_conLat,p_EigenPCG,p_verti,ReConRatio,totalStep,time);
		    } else if (Use_FrictionModel) {
		        p_glatRemoval   -> updateReConLatShearStiffness  (p_conLat,p_EigenPCG,p_verti,totalStep,time);
		    }
		}
		relaxStep++;
		totalStep++;
		i++;
		if (i>maxIter) {
			tripOut << "Max iteration to disconnect/reconnect lattice is reached, iteration stops and proceeds" << std::endl;
			fluidStatus.first  = p_fCal	-> updateCalInfo(qStatus);
			tripOut << "-------------------Finished Stabilizing Lattice Modelling-------------------" << std::endl;
			return false;
		}
		if ((disConCnt==oldReConCnt)&&(reConCnt==oldDisConCnt)&&((disConCnt!=0)||(reConCnt!=0))) {
			tripOut << "Some lattices are oscillating between connecting and disconneting, iteration stops and proceeds" << std::endl;
			break;
		}
		unsigned maxLatChangeTol = std::max((unsigned) std::sqrt(p_glatRemoval->getLatRmNum())/minLatTolerance,minLatChangeTol);
		if (disConCnt+reConCnt<maxLatChangeTol) {
			tripOut << "Only " << disConCnt+reConCnt << " lattices connecting/disconnecting, which is smaller than tolerance "
					<< maxLatChangeTol << " iteration stops and proceeds" << std::endl;
			break;
		}
	} while ((disConCnt!=0) || (reConCnt!=0));
	fluidStatus.first  = p_fCal	-> updateCalInfo(qStatus);
	dualOut << "Disconnect/reconnect lattice process is stabilized in " << i << " step" << std::endl;
	tripOut << "-------------------Finished Stabilizing Fluid-Lattice Modelling-------------------" << std::endl;
	dualOut << "fluidStatus.first, second = " << fluidStatus.first << ' ' << fluidStatus.second << std::endl;
	return true;
}
