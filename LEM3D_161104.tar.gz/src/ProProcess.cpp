/*
 * ProProcess.cpp
 *
 *  Created on: Oct 25, 2013
 *      Author: John K. W. Wong, kwjw2@cam.ac.uk
 */

#include "ProProcess.hpp"

using namespace std;

double GLatForce::calculate	()
{
    double max;

    Clock clock_cal;
    clock_cal.start("LatCal");

    max = calAllLatForce(true,true,true);

    clock_cal.get();
    return max;
}

double GLatForce::calAllLatForce	(	const bool				isCal_inLat,
                                        const bool				isCal_bLat,
                                        const bool				isCal_vLat)
{
    double max_e = -Huge;

    if (isCal_inLat) {
        for (unsigned LatticeID = 0; LatticeID < tLatticeNum; LatticeID++) {
            max_e = std::max(getLatElongation(LatticeID),max_e);
        }
    }

    if (isCal_bLat) {
        for (unsigned LatticeID = tLatticeNum; LatticeID < tLatticeNum+tbLatticeNum; LatticeID++) {
            max_e = std::max(getLatElongation(LatticeID),max_e);
        }
    }

    if (isCal_vLat) {
        for (unsigned LatticeID = tLatticeNum+tbLatticeNum; LatticeID < tLatticeNum+tbLatticeNum+tvLatticeNum; LatticeID++) {
            max_e = std::max(getLatElongation(LatticeID),max_e);
        }
    }

    return max_e;
}

double  GLatForce::getLatElongation    (   const unsigned          LatticeID)
{
    double sum = 0.0;
    unsigned NodeID1 = LatTab[LatticeID].nb[0];
    unsigned NodeID2 = LatTab[LatticeID].nb[1];
    double diff;

    for (unsigned i = 0; i < Dim; i++) {
        diff = GNodeTab[NodeID1].coord[i] - GNodeTab[NodeID2].coord[i]
                 + GNodeTab[NodeID1].d[i] - GNodeTab[NodeID2].d[i];

        sum += diff*diff;
    }
    return sqrt(sum)- LatTab[LatticeID].length;
/*    std::array<double,Dim> delta;
    for (unsigned d = 0; d < Dim; d++) {
        delta[d] = GNodeTab[NodeID1].d[d] - GNodeTab[NodeID2].d[d]
                    + GNodeTab[NodeID1].d0[d] - GNodeTab[NodeID2].d0[d];
    }
    Geometry geo;
    return geo.dot(delta, LatTab[LatticeID].axes[0]);*/
}

double  GLatForce::getLatTensileStress    (   const unsigned          LatticeID)
{
    double sum = 0.0;
    unsigned NodeID1 = LatTab[LatticeID].nb[0];
    unsigned NodeID2 = LatTab[LatticeID].nb[1];
    double diff;
    for (unsigned i = 0; i < Dim; i++) {
        diff = GNodeTab[NodeID1].coord[i] - GNodeTab[NodeID2].coord[i]
                 + GNodeTab[NodeID1].d[i] - GNodeTab[NodeID2].d[i];

        sum += diff*diff;
    }
    double e =  sqrt(sum)- LatTab[LatticeID].length;
    return LatTab[LatticeID].k[0]*e/LatTab[LatticeID].area;
}


double  GLatForce::getLatExtension    (   const unsigned          LatticeID)
{
    unsigned NodeID1 = LatTab[LatticeID].nb[0];
    unsigned NodeID2 = LatTab[LatticeID].nb[1];

    std::array<double,Dim> delta;
    for (unsigned d = 0; d < Dim; d++) {
        delta[d] = GNodeTab[NodeID1].d[d] - GNodeTab[NodeID2].d[d]
                    + GNodeTab[NodeID1].d0[d] - GNodeTab[NodeID2].d0[d];
    }
    Geometry geo;
    return geo.dot(delta, LatTab[LatticeID].axes[0]);
}

/*
double GLatForce::calAllLatForceMultiMax	(	const NodeStateList*	p_nodeState,
                                        		LatStateList*			p_latState,
                                        		const unsigned			maxBreakNo,
                                        		const bool				isCal_inLat,
                                        		const bool				isCal_bLat,
                                        		const bool				isCal_vLat)
{
    unsigned LatticeID;
    vector<double> maxMulti;
    vector<double> latForceList;

    for (unsigned i = 0; i < maxBreakNo; i++)
    {
    	maxMulti.push_back(-Huge);
    }

    if (isCal_inLat)
    {
        for (LatticeID = 0; LatticeID < tLatticeNum; LatticeID++)
        {
            calSingleLatForce (p_nodeState,p_latState,LatticeID);
            latForceList.push_back((*p_latState)[LatticeID].F);
        }
    }

    if (isCal_bLat)
    {
        for (LatticeID = tLatticeNum; LatticeID < tLatticeNum+tbLatticeNum; LatticeID++)
        {
            calSingleLatForce (p_nodeState,p_latState,LatticeID);
            latForceList.push_back((*p_latState)[LatticeID].F);
        }
    }

    if (isCal_vLat)
    {
        for (LatticeID = tLatticeNum+tbLatticeNum; LatticeID < tLatticeNum+tbLatticeNum+tvLatticeNum; LatticeID++)
        {
            calSingleLatForce (p_nodeState,p_latState,LatticeID);
            latForceList.push_back((*p_latState)[LatticeID].F);
        }
    }

    unsigned maxNum = min(maxBreakNo,latForceList.size()/100);

    partial_sort (latForceList.begin(), latForceList.begin()+maxNum,reverseSortDir);

    for (unsigned i = 0; i < maxNum; i++)
    {

    }

    return max;
}

void GLatForce::calSingleLatForce2		( 	const NodeStateList*	p_nodeState,
                                        	LatStateList*			p_latState,
                                        	const unsigned			LatticeID,
                                        	vector<double>*			p_multiMax)
{
    unsigned i,NodeID[2];
    double force = 0.0;
    double sum = 0.0;

    NodeID[0] = GLatticeTab[LatticeID].nb[0];
    NodeID[1] = GLatticeTab[LatticeID].nb[1];

    for (i = 0; i < Dim; i++)
    {
        sum += pow(( GNodeTab[NodeID[0]].coord[i] - GNodeTab[NodeID[1]].coord[i]
                     + (*p_nodeState)[NodeID[0]].d[i] - (*p_nodeState)[NodeID[1]].d[i]), 2);
    }

    force = GLatticeTab[LatticeID].k[0] * (sqrt(sum)- GLatticeTab[LatticeID].length);
    (*p_latState)[LatticeID].F = force;

    if (force > p_multiMax->front())
    {
    	p_multiMax->front() = force;

    }
}

void GLatForce::calSingleLatForce	( 	LatStateHSList*			p_latState,
                                        const unsigned			LatticeID,
                                        double*					max)
{
    double sum = 0.0;
    unsigned NodeID1 = LatTab[LatticeID].nb[0];
    unsigned NodeID2 = LatTab[LatticeID].nb[1];
    double diff;
    for (unsigned i = 0; i < Dim; i++) {
    	diff = GNodeTab[NodeID1].coord[i] - GNodeTab[NodeID2].coord[i]
    	     + GNodeTab[NodeID1].d[i] - GNodeTab[NodeID2].d[i]
    	     + GNodeTab[NodeID1].d0[i] - GNodeTab[NodeID2].d0[i];

        sum += diff*diff;
    }
    (*p_latState)[LatticeID].e = sqrt(sum)- LatTab[LatticeID].length;
    if ((*p_latState)[LatticeID].e > *max) {
        *max = (*p_latState)[LatticeID].e;
    }

    if ((fabs((*p_latState)[LatticeID].e)>1.0)&&(LatTab[LatticeID].k[0]<10.0*Tiny)) {
    	tripOut << sqrt(sum) << " " << LatTab[LatticeID].length << "|("
    			<< (*p_nodeState)[NodeID1].d[0] << "," << (*p_nodeState)[NodeID1].d[1] << "," << (*p_nodeState)[NodeID1].d[2] << "),("
    			<< (*p_nodeState)[NodeID2].d[0] << "," << (*p_nodeState)[NodeID2].d[1] << "," << (*p_nodeState)[NodeID2].d[2] << ")|("
    			<< (*p_nodeState)[NodeID1].d0[0] << "," << (*p_nodeState)[NodeID1].d0[1] << "," << (*p_nodeState)[NodeID1].d0[2] << "),("
    			<< (*p_nodeState)[NodeID2].d0[0] << "," << (*p_nodeState)[NodeID2].d0[1] << "," << (*p_nodeState)[NodeID2].d0[2] << ")" << endl;
    }

}
*/
double GLatForce::getCrackOpening	( 	const unsigned			LatticeID)
{
	unsigned NodeID1 = LatTab[LatticeID].nb[0];
	unsigned NodeID2 = LatTab[LatticeID].nb[1];
/*	if ((GNodeTab[NodeID1].type==Type_Unstable)||(GNodeTab[NodeID1].type==Type_Unstable)) {
		return 0.0;
	}*/
	double sum = 0.0;
	for (unsigned i = 0; i < Dim; i++) {
		double diff = GNodeTab[NodeID1].coord[i] - GNodeTab[NodeID2].coord[i]
//		     + GNodeTab[NodeID1].d0[i] - GNodeTab[NodeID2].d0[i]
		     + GNodeTab[NodeID1].d[i] - GNodeTab[NodeID2].d[i];
		sum += diff*diff;
	}
	return sqrt(sum) - LatTab[LatticeID].length + LatTab[LatticeID].initOpening; // - LatTab[LatticeID].et[0];
}

std::array<double,DofPerNode> GLatForce::getResidual			(	const unsigned			NodeID)
{

	std::array<double,DofPerNode> residual;
	Geometry geo;
	for (unsigned d=0; d<DofPerNode; d++) {
		residual[d] = 0.0;
	}
	for (unsigned k=0; k<GNodeTab[NodeID].nbNodeID.size(); k++) {
		unsigned nbNodeID = GNodeTab[NodeID].nbNodeID[k];
		unsigned LatticeID = GNodeTab[NodeID].nbLatticeID[k];
		std::array<double,Dim> delta;
		for (unsigned d=0; d<Dim; d++) {
			delta[d] = GNodeTab[nbNodeID].d[d] - GNodeTab[NodeID].d[d] ;
		}
		double f0 = geo.dot(delta,LatTab[LatticeID].axes[0]);
		for (unsigned d=0; d<Dim; d++) {
			residual[d] += f0*LatTab[LatticeID].axes[0][d]*LatTab[LatticeID].k[0];
		}
		if (KNum>1) {
			double f1 = geo.dot(delta,LatTab[LatticeID].axes[1]);
			double f2 = geo.dot(delta,LatTab[LatticeID].axes[2]);
			for (unsigned d=0; d<Dim; d++) {
				residual[d] += f1*LatTab[LatticeID].axes[1][d]*LatTab[LatticeID].k[1];
				residual[d] += f2*LatTab[LatticeID].axes[2][d]*LatTab[LatticeID].k[1];
			}

		}
		if (KNum >2) {
			std::array<double,Dim> rDelta,rf;
			for (unsigned d=0; d<Dim; d++) {
				rDelta[d] = GNodeTab[nbNodeID].d[d+Dim] - GNodeTab[NodeID].d[d+Dim];
			}
			for (unsigned d=0; d<Dim; d++) {
				rf[d] = geo.dot(rDelta,LatTab[LatticeID].axes[d]);
			}
			for (unsigned d=0; d<Dim; d++) {
				residual[d+Dim] += rf[d]*LatTab[LatticeID].axes[0][d]*(LatTab[LatticeID].k[2]+LatTab[LatticeID].k[3]);
				residual[d+Dim] += rf[d]*LatTab[LatticeID].axes[1][d]*LatTab[LatticeID].k[2];
				residual[d+Dim] += rf[d]*LatTab[LatticeID].axes[2][d]*LatTab[LatticeID].k[3];
			}
		}
	}
	for (unsigned d=0; d<DofPerNode; d++) {
		residual[d] += GNodeTab[NodeID].extF[d];
	}
	return residual;
}

/*
Eigen::VectorXd GLatForce::getMemForce			(	const unsigned			NodeID,
													const unsigned			k)
{
	PCG_Eigen pcg;
	Eigen::MatrixXd     lSM(DofPerNode, 2*DofPerNode);
	if (KNum==1) {
		Eigen::MatrixXd     lSM2 = pcg.getSpringLocalSM(NodeID,k);
		lSM.block(0,0,DofPerNode,DofPerNode) = lSM2;
		lSM.block(0,DofPerNode,DofPerNode,DofPerNode) = -lSM2;
	} else if (KNum==2) {
		Eigen::MatrixXd     lSM2 = pcg.getShearLocalSM(NodeID,k);
		lSM.block(0,0,DofPerNode,DofPerNode) = lSM2;
		lSM.block(0,DofPerNode,DofPerNode,DofPerNode) = -lSM2;
	} else {
		lSM = pcg.getFullLocalSM2(NodeID,k);
	}
	Eigen::VectorXd		vd(2*DofPerNode);
	unsigned nbNodeID = GNodeTab[NodeID].nbNodeID[k];
	for (unsigned d=0; d<DofPerNode; d++) {
		vd[d] = GNodeTab[NodeID].d[0] + GNodeTab[NodeID].d0[0];
		vd[d+DofPerNode] = GNodeTab[nbNodeID].d[0] + GNodeTab[nbNodeID].d0[0];
	}
	return lSM*vd;
}
*/
double GLatForce::getMaxLatForce			(	const unsigned			NodeID)
{
	double maxForce = 0.0;
	Geometry geo;
	for (unsigned k=0; k<GNodeTab[NodeID].nbLatticeID.size(); k++) {
		unsigned LatticeID = GNodeTab[NodeID].nbLatticeID[k];
		unsigned nbNodeID = GNodeTab[NodeID].nbNodeID[k];
		std::array<double,Dim> delta;
		for (unsigned d=0; d<Dim; d++) {
			delta[d] = GNodeTab[nbNodeID].d[d] - GNodeTab[NodeID].d[d];
		}
		double resultantForce = 0.0;
		if (KNum==1) {
			resultantForce = geo.dot(delta,LatTab[LatticeID].axes[0])*LatTab[LatticeID].k[0];
		} else {
			double f0 = geo.dot(delta,LatTab[LatticeID].axes[0])*LatTab[LatticeID].k[0];
			double f1 = geo.dot(delta,LatTab[LatticeID].axes[1])*LatTab[LatticeID].k[1];
			double f2 = geo.dot(delta,LatTab[LatticeID].axes[2])*LatTab[LatticeID].k[1];
			resultantForce = std::sqrt (f0*f0+f1*f1+f2*f2);
		}
		if (maxForce < resultantForce) {
			maxForce = resultantForce;
		}
	}
	if (maxForce<Tiny) {
		maxForce = 1.0;
	}
	return maxForce;
}

double GLatForce::getMaxLatMoment			(	const unsigned			NodeID)
{
	double maxMoment = 0.0;
	Geometry geo;
	for (unsigned k=0; k<GNodeTab[NodeID].nbLatticeID.size(); k++) {
		unsigned LatticeID = GNodeTab[NodeID].nbLatticeID[k];
		unsigned nbNodeID = GNodeTab[NodeID].nbNodeID[k];
		std::array<double,Dim> delta;
		for (unsigned d=0; d<Dim; d++) {
			delta[d] = GNodeTab[nbNodeID].d[d+Dim] - GNodeTab[NodeID].d[d+Dim];
		}
		double resultantMoment = 0.0;
		double f0 = geo.dot(delta,LatTab[LatticeID].axes[0])*(LatTab[LatticeID].k[2]+LatTab[LatticeID].k[3]);
		double f1 = geo.dot(delta,LatTab[LatticeID].axes[1])*LatTab[LatticeID].k[2];
		double f2 = geo.dot(delta,LatTab[LatticeID].axes[2])*LatTab[LatticeID].k[3];
		resultantMoment = std::sqrt (f0*f0+f1*f1+f2*f2);
		if (maxMoment < resultantMoment) {
			maxMoment = resultantMoment;
		}
	}
	if (maxMoment<Tiny) {
		maxMoment = 1.0;
	}
	return maxMoment;
}

/*
bool GLatForce::isCrackReopen		( 	const NodeStateList*	p_nodeState,
										const LatStateHSList*	p_latState,
        								const unsigned			LatticeID,
        								const double			minApecture)
{
	if ((GNodeTab[NodeID1].type==Type_Unstable)||(GNodeTab[NodeID1].type==Type_Unstable)) {
		tripOut << "Warning!!! [GLatForce::isCrackReopen] : One/both nodes are unstable. Return false." << std::endl;
		return false;
	}
	if (!(*p_latState)[LatticeID].isBreak) {
		return false;
	}
	double newApecture = getCrackOpening(p_nodeState,LatticeID);
	if (newApecture > minApecture) {
		return true;
	}
	unsigned NodeID1 = LatTab[LatticeID].nb[0];
	unsigned NodeID2 = LatTab[LatticeID].nb[1];
	double sum = 0.0;
	for (unsigned i = 0; i < Dim; i++) {
		double diff = GNodeTab[NodeID1].coord[i] - GNodeTab[NodeID2].coord[i]
		     + (*p_nodeState)[NodeID1].d0[i] - (*p_nodeState)[NodeID2].d0[i]
		     + (*p_nodeState)[NodeID1].old_d[i] - (*p_nodeState)[NodeID2].old_d[i];
		sum += diff*diff;
	}
	double oldApecture = sqrt(sum) - LatTab[LatticeID].length - LatTab[LatticeID].et[0];
	if (newApecture > oldApecture) {
		return true;
	}
}
*/


