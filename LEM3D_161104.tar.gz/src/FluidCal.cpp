/*
 * FluidCal.cpp
 *
 *  Created on: May 20, 2014
 *      Author: John K. W. Wong, kwjw2@cam.ac.uk
 */

#include "FluidCal.hpp"
/*
FluidCal::FluidCal() {
	// TODO Auto-generated constructor stub

}
*/
/*
FluidCal::~FluidCal() {
	// TODO Auto-generated destructor stub
}
*/
FluidCal::~FluidCal() {}
FluidCal::FluidCal() {
//	maxCvDist = 0.0;
//	maxCoordNo = 0;
	q_tolerance = 1e-6;
	minApecture = 1e-5;
	DOFLimit = 10000;
	time = 0.0;
	oldTotalArea = 0.0;
}

FluidCal::FluidCal			(	const double 		_viscosity,
								const double		_initTime,
								const double        _timeStep,
								const double 		_q_tolerance,
								const double		_minApecture,
								const double		_maxIncr,
								const double		_maxDecr,
								const double		_pMinAbs,
								const double		_pMaxAbs,
								const unsigned		_DOFLimit) {
	viscosity = _viscosity;
	q_tolerance = _q_tolerance;
	minApecture = _minApecture;
	maxIncrBase = maxIncrInUse = _maxIncr;
	maxDecrBase = maxDecrInUse = _maxDecr;

	oldInjP = InitForce;
	pMinAbs = _pMinAbs;
	pMin = _maxDecr*InitForce;
	pMax = _maxIncr*InitForce;
	pMaxAbs = _pMaxAbs;
	DOFLimit = _DOFLimit;
	time = _initTime;
//	initTimeStep = _timeStep;
	initBHstorage = 0.0;
	timeStep = _timeStep;
	isInjPChange = true;
	isFirstStep = true;
	checkpMin = checkpMax = false;
}

bool FluidCal::calculate		(	std::pair<bool,bool>& 	qStatus,
									const unsigned			step)
{
//	static unsigned convergeCnt = 0;
//	static unsigned relaxStep = 0;
//	static bool		isQbounded = false;
	std::pair<bool,bool>		status(false,false);
//	activeConFNode = conFNode;
/*	static bool isFirst = true;
	if (isFirst) {
	    setInitLeakOff ();
	    isFirst = false;
	}*/
	const double    ratioEnhance = 10.0;
	if (pipeList.empty()) {
		calNodeNum = 0;
		tripOut << "There is no pipe available for fluid flow, no calculation is done!" << '\n';
		return false;
	}
	dualOut << "Start calculation of fluid pressure..." << '\n';
	Clock clock;
	clock.start("Fluid");
	bool isFluidNetworkChanged = true;
	unsigned fCalStep = 0;
	do {
		dualOut << "--------fCalStep = " << fCalStep << " starts--------" << '\n';
		qStatus = fillQ(initialize(),step);
		maxIncrInUse = maxIncrBase;
		maxDecrInUse = maxDecrBase;
		if ((calNodeNum==0)||(!fillH())) {
			dualOut << "Only injection node is active, solving is not required, pressure is set to 0.0" << '\n';
			p.fill(0.0);
			maxIncrInUse = 1.0 + std::fabs(maxIncrBase-1.0)*ratioEnhance;
			maxDecrInUse = std::max ((1.0 - std::fabs(1.0 - maxDecrBase)*ratioEnhance),0.0);
			std::cout << " maxDecrBase  = " << maxDecrBase << " maxDecrInUse = " << maxDecrInUse << std::endl;
			break;
		} else {
			unsigned minIter = (unsigned) (2.5*std::sqrt(fNodeList.size()));
			unsigned maxIter = 15*minIter;
			if (10*calNodeNum<DOFLimit) {
				status.second = sparseCholeskySolve ();
				dualOut << "Cholesky residual = " << getResidual() << '\n';
				if (!status.second) {
					tripOut << "Cholesky is not stable, try to solve by PCG..." << '\n';
					fillP();
					status.second = serialSolve(minIter,maxIter,PCG_Precision);
					dualOut << "PCG residual = " << getResidual() << '\n';
					if (!status.second) {
						tripOut << "Calculation unstable, reset to hydrostatic pressure and start again";
						p.fill(getPriInjP());
//						return false;
					}
				}
			} else {
				fillP();
				status.second = serialSolve(minIter,maxIter,PCG_Precision);
				dualOut << "PCG residual = " << getResidual() << '\n';
				if (!status.second) {
					tripOut << "PCG is not stable, try to solve by Cholesky..." << '\n';
					status.second = sparseCholeskySolve ();
					dualOut << "Cholesky residual = " << getResidual() << '\n';
					if (!status.second) {
						tripOut << "Calculation unstable, reset to hydrostatic pressure and start again";
						p.fill(getPriInjP());
//						return false;
					}
				}
			}
		}
		updateOldP();
		isFluidNetworkChanged = updateActiveConFNode();
		fCalStep++;
	} while (isFluidNetworkChanged && (fCalStep<5));
	isInjPChange = false;
	dualOut << "--------fluid calculation finished in " << fCalStep << " step(s)--------" << '\n';
	dualOut << "Fluid calculation completed..." << '\n';
	clock.get();
	return true;
}


bool FluidCal::calculate_static		(	std::pair<bool,bool>& 	qStatus,
										const unsigned			step)
{
	std::pair<bool,bool>		status(false,false);
/*	static bool isFirst = true;
	if (isFirst) {
	    setInitLeakOff ();
	    isFirst = false;
	}*/
//	activeConFNode = conFNode;
	if (pipeList.empty()) {
		calNodeNum = 0;
		tripOut << "There is no pipe available for fluid flow, no calculation is done!" << '\n';
		return false;
	}
	dualOut << "Start calculation of fluid pressure..." << '\n';
	qStatus = fillQ(initialize(),step);
	p.resize(calNodeNum);
	p.fill(getPriInjP());
	updateOldP();
	updateActiveConFNode();
	isInjPChange = false;
	dualOut << "Fluid static calculation completed..." << '\n';
	return true;
}

bool FluidCal::updateCalInfo	(	std::pair<bool,bool>& 		qStatus)
{
	static unsigned convergeCnt = 0;
	static bool		isQbounded = false;
	static unsigned relaxStep = 0;
	if ((qStatus.second)||(relaxStep>10)) {
//	if (qStatus.second) {
		if ((qStatus.first)) {
			tripOut << "Global flow rate convergence achieved, proceed to next time step" << '\n';
			initizeNextStep(convergeCnt,relaxStep,isQbounded);
			isInjPChange = true;
			return true;
		}
		char fileName[255];
		std::sprintf(fileName,"%s/%sfShortLog.vtk",OutputSubFolder,OutputFilePrefix);
		std::ofstream file(fileName, std::ios::out | std::ios::app);
		file << getPriInjP() << '\t' << normRes << '\n';
		relaxStep = 0;
		if (!isQbounded) {
			isQbounded = vertifyPlimits();
			if (isQbounded) {
				updatePriInjPressure();
//				calculate(p_nodeState,step,timeStep);
			}
			isInjPChange = true;
		} else {
//			calculate(p_nodeState,step,timeStep);
			if ((pMax-pMin)/(pMaxAbs-pMinAbs)<1e-4) {
				tripOut << "Pressure difference is small, proceed to next time step" << '\n';
				initizeNextStep(convergeCnt,relaxStep,isQbounded);
				isInjPChange = true;
				return true;
			}
			updatePriInjPressureHighOrder(timeStep);
			isInjPChange = true;
		}
	}
	relaxStep++;
	return false;
}

void FluidCal::initizeNextStep	(	unsigned				&convergeCnt,
									unsigned				&relaxStep,
									bool					&isQbounded)
{
	char fileName[255];
	static unsigned old_fNodeNum = 0;
	static int old_activefNodeNum = 0;
	static bool isFirst = true;
	std::sprintf(fileName,"%s/%spHist.txt",OutputSubFolder,OutputFilePrefix);
	std::ofstream file(fileName, std::ios::out | std::ios::app);
	updateLeakOff ();
//	updateOldFractureStorage ();
	if (isFirst) {
	    file << "time" << '\t' << "P" << '\t' << "increase in total fluid node" << '\t'
	         << "increase in active fluid node" << '\t' << "calNodeNum" << '\t' << "Fluid node num" << '\t'
	         << "active node ratio" << '\t'<< "fluidEfficieny" << '\n';
	    isFirst = false;
	}
	file << time << '\t' << getPriInjP() << '\t' << fNodeList.size() - old_fNodeNum << '\t'
	        << ((int) calNodeNum) - old_activefNodeNum << '\t' << calNodeNum << '\t' << fNodeList.size() << '\t'
	        << ((double) calNodeNum)/fNodeList.size()<< '\t'<< fluidEfficieny << '\n';
	time += timeStep;
/*	if (isFirst) {
	    timeStep = initTimeStep;
	    isFirst = false;
	}*/
	pMin = getPriInjP();
	old_fNodeNum = fNodeList.size();
	old_activefNodeNum = calNodeNum;
	checkpMin = checkpMax = false;
//	pMax = std::min(2.0*pMin,pMaxAbs);
	double totalArea = getActiveTotalArea ();
	if (totalArea > 2.0*oldTotalArea) {
		dualOut << "totalArea, oldArea = " << totalArea << ',' << oldTotalArea << std::endl;
	    timeStep *=2.0;
	    dualOut << "************TimeStep is now increased to " << timeStep << "************" << std::endl;
	    oldTotalArea *= 2.0;
	}
	if (TimePerStep>timeStep) {
	    timeStep = TimePerStep;
	}
	convergeCnt++;
	isQbounded = false;
	isFirstStep = false;
	relaxStep = 0;
}

double FluidCal::getActiveTotalArea ()
{
    double totalArea = 0.0;
    for (unsigned i=0; i<fNodeList.size(); i++) {
        if (fNodeList[i].isActive()) {
            double LatticeID = fNodeList[i].LatticeID;
            if (ProblemID==2) {
                if (!std::binary_search(initCrackList.begin(),initCrackList.end(),LatticeID)) {
                    totalArea += LatTab[fNodeList[i].LatticeID].area;
                }
            } else {
                totalArea += LatTab[fNodeList[i].LatticeID].area;
            }
        }
    }
    return totalArea;
}

void FluidCal::setNotchList          (   const std::vector<unsigned>*    p_latList)
{
    dualOut << "FluidCal::setNotchList..." << std::endl;
    notchList.clear();
//    notchList = *p_latList;
    GLatForce lforce;
    CustomPair<unsigned,double> cp;
    for (unsigned i=0 ; i< p_latList->size(); i++ ) {
        unsigned LatticeID = (*p_latList)[i];
        cp.i1 = LatticeID;
        cp.i2 = lforce.getCrackOpening(LatticeID)*LatTab[LatticeID].area;
        notchList.push_back(cp);
    }
    std::sort(notchList.begin(),notchList.end());
/*    for (unsigned i=0 ; i<notchList.size(); i++ ) {
        std::cout << notchList[i] << ' ';
    }*/
}

void FluidCal::setBHInitStorage ()
{
    GLatForce lforce;
    initBHstorage = 0.0;
    if ((GeometryID==1)||(GeometryID==4)) {
        for (unsigned i=0; i<initCrackList.size(); i++) {
            unsigned LatticeID = initCrackList[i];
            initBHstorage += lforce.getCrackOpening(LatticeID)*LatTab[LatticeID].area;
        }
    }
    dualOut << "Initial borehole storage = " << initBHstorage << std::endl;
}

double FluidCal::getBHstorage ()
{
    double storage = 0.0;
    GLatForce lforce;
    for (unsigned i=0; i<initCrackList.size(); i++) {
        unsigned LatticeID = initCrackList[i];
        storage += lforce.getCrackOpening(LatticeID)*LatTab[LatticeID].area;
    }
    std::cout << "Storage , initBHstorage = " << storage << ',' << initBHstorage << std::endl;
    return std::max(0.0,storage - initBHstorage);
}
void FluidCal::setInitLeakOff ()
{
    dualOut << "Set initial leak off..." << std::endl;
    double totalInitLeakOff = 0.0;
    for (unsigned i=0; i<fNodeList.size(); i++) {
        fNodeList[i].t_exp = InitTime-timeStep;
        fNodeList[i].leakVol = 2.0*fNodeList[i].Cl*std::sqrt(InitTime-timeStep);
        totalInitLeakOff += fNodeList[i].leakVol;
    }
    dualOut << "Initial leak off volume = " << totalInitLeakOff
            << " initial fluid efficiency = " << (InjectRate*InitTime-totalInitLeakOff)/(InjectRate*InitTime) << std::endl;
}

void FluidCal::setInitialArea (     ConnectLat*         p_conLat)
{
    std::vector<unsigned>   group0 = p_conLat->getGroup(0);
    oldTotalArea = 0;
    for (unsigned i=0; i<group0.size(); i++) {
        oldTotalArea += LatTab[group0[i]].area;
    }
    if (ProblemID==2) {
        for (unsigned i=0; i<initCrackList.size(); i++) {
            oldTotalArea -= LatTab[initCrackList[i]].area;
        }
    }
//    oldTotalArea = getActiveTotalArea ();
    dualOut << "Set oldTotalArea = " << oldTotalArea << std::endl;
}

bool FluidCal::vertifyPlimits	()
{

	const double adjRatio = 1.000;
	if (!checkpMin) {
		if (normRes>0.0) {
			checkpMin = true;
//			updateP(pMax);
//			for (unsigned i=0; i<priINodeList.size(); i++) {
//				priINodeList[i].p = pMax;
//			}
			iterHist[0] = PRpair(pMin,normRes);
			tripOut << "pMin is captured, now try to capture pMax" << '\n';
			pMin = getPriInjP();
			if (normRes<1.0) {
			    pMax = std::min(std::min(pMin/(1.0-normRes)*adjRatio,maxIncrInUse*pMin),pMaxAbs);
			} else {
			    pMax = maxIncrInUse*pMin;
			}
			updateP(pMax);
			return false;
		} else {
		    pMin = getPriInjP();
			if (std::fabs(pMin-pMinAbs)<Tiny) {
				time +=timeStep;
				tripOut << "pMin is too large but cannot be further reduced as it reaches pMinAbs already,increase the time by one timeStep "
						<< ", time = " << time << '\n';
			}
			pMin = std::max(std::max(pMin/(1.0-normRes)/adjRatio,maxDecrInUse*pMin),pMinAbs);
			tripOut << "pMin is too large, try again with pMin = pMin/(1.0-normRes)/adjRatio "
					<< "or pMinAbs, whichever is larger, pMin = " << pMin << '\n';
			updateP(pMin);
//			for (unsigned i=0; i<priINodeList.size(); i++) {
//				priINodeList[i].p = pMin;
//			}
			return false;
		}
	} else if (!checkpMax) {
		if (normRes<0.0) {
			checkpMax = true;
			iterHist[1] = PRpair(pMax,normRes);
			tripOut << "pMin and pMax are captured, now solution is bounded" << '\n';
			return true;
		} else {
			pMax = std::min(pMax/(1.0-normRes)*adjRatio,pMaxAbs);
			tripOut << "pMax is too small, try again with pMax = pMin-normRes/(normRes+1.0)*pMin*adjRatio "
					<<	"or pMaxAbs, whichever is smaller, pMax = " << pMax << '\n';
			updateP(pMax);
//			for (unsigned i=0; i<priINodeList.size(); i++) {
//				priINodeList[i].p = pMax;
//			}
			return false;
		}
	}
	return true;
}

std::pair<bool,bool> FluidCal::fillQ					(	const std::vector<IDpair>		qinList,
															const unsigned					step)
{
	//Storage of primary injection nodes which are excluded in solving system of equations
	std::pair<bool,bool> 		qStatus;
	if (priINodeList.empty()) {
		tripOut << "---WARNING---No injection node!!!" << '\n';
	}
	char fileName[255];
	std::sprintf(fileName,"%s/%sfLog.vtk",OutputSubFolder,OutputFilePrefix);
	std::ofstream file(fileName, std::ios::out | std::ios::app);
	if (step==0) {
		file << "# time" << '\t' << "step" << '\t' << "Pinj" << '\t' << "Storage" << '\t' <<"dQ" << '\t' << "Res" << '\n';
	}
	if (true) {
		file << time << '\t' << step << '\t';
	}
	q.resize(calNodeNum);
	q.fill(0.0);
	unsigned LatticeID;
	double sum_qin = 0.0;
	double sum_s = 0.0;

	GLatForce lforce;
	for (std::vector<PriINode>::iterator it=priINodeList.begin(); it!=priINodeList.end(); ++it) {
		LatticeID = fNodeList[it->fNodeID].LatticeID;
		sum_qin += it->qin;
		double s;
		if (!std::binary_search(initCrackList.begin(),initCrackList.end(),LatticeID)) {
		    s = std::max(lforce.getCrackOpening(LatticeID),0.0)*LatTab[LatticeID].area;
		} else {
		    s = 0.0;
		}
		sum_s += -s/time;
	}
//	std::vector<double>		storage;
	for (unsigned DOF=0; DOF<calNodeNum; DOF++) {
		LatticeID = fNodeList[DOFtoFNode[DOF]].LatticeID;
		double s=0.0,l=0.0;
		if (!std::binary_search(initCrackList.begin(),initCrackList.end(),LatticeID)) {
		    s = std::max(lforce.getCrackOpening(LatticeID),0.0)*LatTab[LatticeID].area;
		    l = getLeakOff(DOFtoFNode[DOF])+getDeltaLeakOff(DOFtoFNode[DOF]);
		    if (GeometryID ==4) {
		        unsigned i = std::lower_bound(notchList.begin(),notchList.end(),LatticeID)-notchList.begin();
		        if (notchList[i]==LatticeID) {
//		            s -= notchList[i].i2;
		            sum_s -= -notchList[i].i2/time;
		        }
		    }
		}
		q[DOF] = -(s+l)/time;
		sum_s += -s/time;
//		storage.push_back(q[DOF]);
	}

	static double oldDeltaLeakOff = 0.0;
	static double oldBHstorage = 0.0;
	double bHstorage = -getBHstorage();
	double newDeltaLeakOff = -getDeltaLeakOff();
	double leakOff = -getTotalLeakOff();
	double rate_leakOff = (newDeltaLeakOff+leakOff)/time;
	double rate_BHstorage = bHstorage/time;
//	double rate_leakOff = (newDeltaLeakOff)/timeStep;

//	printVectors	(step,false,true,false);
	for (unsigned i=0; i< qinList.size(); i++) {
		sum_qin +=iNodeList[qinList[i].first].qin;
	}
	static double               oldSum_s = 0.0;
	double deltaQ		= (sum_s - oldSum_s + (newDeltaLeakOff-oldDeltaLeakOff)/time+(bHstorage-oldBHstorage)/time) / sum_qin;
//	double deltaQ		= (sum_s - oldSum_s) / sum_qin;
	qStatus.second = ((std::fabs(deltaQ)<1e-3)&&(!isInjPChange));
	oldSum_s = sum_s;
	for (unsigned i=0; i< qinList.size(); i++) {
		q[fNodeToDOF[qinList[i].second]] += iNodeList[qinList[i].first].qin;
		sum_qin +=iNodeList[qinList[i].first].qin;
	}
	dualOut << "sum_s, sum_qin, rate_leakOff, rate_BHstorage = "
	        << sum_s << "," << sum_qin << ' ' << rate_leakOff << ' ' << rate_BHstorage << '\n';
	if (sum_qin+rate_leakOff<0.0) {
	    dualOut << "Leak off is too large, increase time by one timeStep" << std::endl;
	    time += timeStep;
	    return fillQ(qinList,step);
	}
	normRes = (sum_s+rate_BHstorage+sum_qin+rate_leakOff)/(sum_qin+rate_leakOff);
	dualOut << "normRes = (sum_s+sum_qin+rate_leakOff)/(sum_qin+rate_leakOff) = " << normRes << '\n';
	fluidEfficieny = -(sum_s+rate_BHstorage)/(sum_qin);
	dualOut << "Fluid efficiency = " << fluidEfficieny << std::endl;
	oldDeltaLeakOff = newDeltaLeakOff;
	oldBHstorage = bHstorage;
//	if (isInjPChange) {
//		file << oldInjP;
//	} else {
		file << getPriInjP();
//	}
	file << '\t' << sum_s << '\t' << deltaQ << '\t' << normRes << '\n';
	if (std::fabs(normRes)<q_tolerance) {
		qStatus.first = true;
		return qStatus;
	} else {

		qStatus.first = false;
		return qStatus;
	}
}

double FluidCal::getTotalLeakOff ()
{
    double totalLeakOff = 0.0;
    for (unsigned fNodeID=0; fNodeID<fNodeList.size(); fNodeID++) {
        totalLeakOff += fNodeList[fNodeID].leakVol;
    }
    return totalLeakOff;
}


double FluidCal::getDeltaLeakOff () {
	double delta = 0.0;
	double dt;
	if (isFirstStep) {
	    dt = time;
	} else {
	    dt = timeStep;
	}
	for (unsigned DOF=0; DOF<calNodeNum; DOF++) {
	    unsigned fNodeID = DOFtoFNode[DOF];
		delta += 2.0*fNodeList[fNodeID].Cl*LatTab[fNodeList[fNodeID].LatticeID].area
                *(std::sqrt(fNodeList[fNodeID].t_exp+dt)-std::sqrt(fNodeList[fNodeID].t_exp));
	}
	return delta;
}

double FluidCal::getDeltaLeakOff (   const unsigned      fNodeID) {
    return 2.0*fNodeList[fNodeID].Cl*LatTab[fNodeList[fNodeID].LatticeID].area
                *(std::sqrt(fNodeList[fNodeID].t_exp+timeStep)-std::sqrt(fNodeList[fNodeID].t_exp));
}

double FluidCal::getLeakOff (   const unsigned      fNodeID)
{
    return fNodeList[fNodeID].leakVol+2.0*fNodeList[fNodeID].Cl*LatTab[fNodeList[fNodeID].LatticeID].area
            *(std::sqrt(fNodeList[fNodeID].t_exp+timeStep)-std::sqrt(fNodeList[fNodeID].t_exp));
}

void FluidCal::updateLeakOff ()
{
    double dt;
    if (isFirstStep) {
        dt = time;
    } else {
        dt = timeStep;
    }
    for (unsigned DOF=0; DOF<calNodeNum; DOF++) {
        unsigned fNodeID = DOFtoFNode[DOF];
        double currentLeakOff = 2.0*fNodeList[fNodeID].Cl*LatTab[fNodeList[fNodeID].LatticeID].area
                *(std::sqrt(fNodeList[fNodeID].t_exp+dt)-std::sqrt(fNodeList[fNodeID].t_exp));
        fNodeList[fNodeID].leakVol += currentLeakOff;
        fNodeList[fNodeID].t_exp += dt;
    }
    for (std::vector<PriINode>::iterator it=priINodeList.begin(); it!=priINodeList.end(); ++it) {
        double currentLeakOff = 2.0*fNodeList[it->fNodeID].Cl*LatTab[fNodeList[it->fNodeID].LatticeID].area
                        *(std::sqrt(fNodeList[it->fNodeID].t_exp+dt)-std::sqrt(fNodeList[it->fNodeID].t_exp));
        fNodeList[it->fNodeID].leakVol += currentLeakOff;
        fNodeList[it->fNodeID].t_exp += dt;
    }
}

void FluidCal::enforceGlobalContinuity 	(	const double				residual,
											const double				sum_s,
											const std::vector<double>*	p_storage)
{
/*	char fileName[255];
	sprintf(fileName,"%s/%sstorage.vtk",OutputSubFolder,OutputFilePrefix);
	std::ofstream file(fileName, std::ios::out | std::ios::app);
	file << "q before = " << q << '\n';*/
	for (unsigned DOF = 0; DOF < calNodeNum; DOF++) {
		q[DOF] -= residual*((*p_storage)[DOF])/sum_s;
	}
}

void FluidCal::fillP ()
{
	p.resize(calNodeNum);
	p.fill(0.0);
	for (unsigned DOF = 0; DOF < calNodeNum; DOF++) {
		p[DOF] = fNodeList[DOFtoFNode[DOF]].old_p;
	}
}

void FluidCal::updateOldP ()
{
	for (unsigned DOF = 0; DOF < calNodeNum; DOF++) {
		fNodeList[DOFtoFNode[DOF]].old_p = p[DOF];
		if (DOF<10) {
		    std::cout << p[DOF] << ' ';
		}
	}
	std::cout << std::endl;
}

double FluidCal::updateP 	(	const double		pNew)
{
	double pUpdate = std::max(std::min(pNew,oldInjP*maxIncrInUse),oldInjP*maxDecrInUse);
	std::cout << maxIncrInUse << " " << maxDecrInUse << std::endl;
	std::cout << "oldInjP = " << oldInjP << " pNew = " << pNew << " pUpdated = " << pUpdate << std::endl;
	for (unsigned i=0; i<priINodeList.size(); i++) {
		priINodeList[i].p = pUpdate;
	}
	oldInjP = pUpdate;
	return pUpdate;
//	p.fill(pNew);
}

std::vector<IDpair> FluidCal::initialize	()
{
	DOFtoFNode.clear();
	dualFNode.clear();
	std::vector<unsigned>	nbPriINodeList = getPriINodeNbList();
	nbPriNum = nbPriINodeList.size();
	unsigned fNodeID;
	for (unsigned i=0; i<nbPriNum; i++) {
		fNodeID = nbPriINodeList[i];
		if (conFNode.find(fNodeID)!=conFNode.end()) {
//		if (fNodeList[fNodeID].isActive()) {
			DOFtoFNode.push_back(fNodeID);
		}
	}
	DOFseg1 = DOFtoFNode.size();
	std::vector<unsigned>	chkList = DOFtoFNode;
	for (unsigned i=0; i<priINodeList.size(); i++) {
		chkList.push_back(priINodeList[i].fNodeID);
	}
	std::vector<IDpair>	qinList;
	for (unsigned i=0; i<iNodeList.size(); i++) {
		fNodeID = iNodeList[i].fNodeID;
		if (conFNode.find(fNodeID)!=conFNode.end()) {
//		if (fNodeList[fNodeID].isActive()) {
			IDpair	iNodeAndfNodeID (i,fNodeID);
			qinList.push_back(iNodeAndfNodeID);
			if (std::find(chkList.begin(),chkList.end(),fNodeID)==chkList.end()) {
				DOFtoFNode.push_back(fNodeID);
			} else {
				dualFNode.push_back(fNodeID);
			}
		}
	}
	DOFseg2 = DOFtoFNode.size();
	chkList.insert(chkList.end(),DOFtoFNode.begin()+DOFseg1,DOFtoFNode.end());
	for (std::set<unsigned>::iterator it = conFNode.begin(); it != conFNode.end(); ++it) {
		fNodeID = *it;
			if(std::find(chkList.begin(),chkList.end(),*it)==chkList.end()) {
//				&&(activeConFNode.find(fNodeID)!=activeConFNode.end())){
			DOFtoFNode.push_back(fNodeID);
		}
	}
	calNodeNum = DOFtoFNode.size();
	std::cout << "calNodeNum = " << calNodeNum << '\n';
	fNodeToDOF.resize(fNodeList.size(),calNodeNum);
	for (unsigned DOF=0; DOF<DOFtoFNode.size();DOF++) {
		fNodeToDOF[DOFtoFNode[DOF]]=DOF;
	}
	return qinList;
}

void FluidCal::updateOldFractureStorage	()
{
	unsigned LatticeID;
	GLatForce lforce;
	double sum = 0.0;
	dualOut << "updating Old Fluid Storage..." << '\n';
	for (unsigned fNodeID=0; fNodeID < fNodeList.size(); fNodeID++) {
	    fNodeList[fNodeID].old_s = 0.0;
	}
	for (std::vector<PriINode>::iterator it=priINodeList.begin(); it!=priINodeList.end(); ++it) {
	    LatticeID = fNodeList[it->fNodeID].LatticeID;
	    double s;
	    if (!std::binary_search(initCrackList.begin(),initCrackList.end(),LatticeID)) {
	        fNodeList[it->fNodeID].old_s = std::max(lforce.getCrackOpening(LatticeID),0.0)*LatTab[LatticeID].area;
	        sum += fNodeList[it->fNodeID].old_s;
	    }
	}
	for (unsigned DOF=0; DOF<calNodeNum; DOF++) {
	    unsigned fNodeID = DOFtoFNode[DOF];
	    LatticeID = fNodeList[fNodeID].LatticeID;
	    fNodeList[fNodeID].old_s = std::max(lforce.getCrackOpening(LatticeID),0.0)*LatTab[LatticeID].area;
	    sum += fNodeList[fNodeID].old_s;
	}
	dualOut << "Total Fluid storage = " << sum << '\n';
}


void FluidCal::updatePriInjPressure					()
{
	dualOut << "Adjusting primary injection pressure (secant method)..." << '\n';
	double pNow = getPriInjP();
	double pNew = linearPredict(pMax,normRes);
	pNew = priInjPressureAdjust(pMax,pNew);
	double pUpdated = updateP(pNew);
	dualOut << " normRes = " << normRes << " Injection pressure becomes = " << pUpdated << '\n';
}

double FluidCal::updatePriInjPressure                 (   const double        norm)
{
    dualOut << "Adjusting primary injection pressure with inputted norm..." << '\n';
    double pNow = getPriInjP();
    double pNew = std::min(linearPredict(pNow,1.0-norm),MaxPressure);
//    pNew = priInjPressureAdjust(pMax,pNew);
//    updateP(pNew);
    dualOut << "pNow = " << pNow << " pNew = " << pNew << std::endl;
    dualOut << " normRes = " << 1.0-norm << " Injection pressure becomes = " << pNew << '\n';
    return pNew;
}

double FluidCal::priInjPressureAdjust						(	const double		pNow,
																const double		pNew)
{
	if (normRes>0.0) {
		pMin = pNow;
		iterHist[0] = PRpair(pMin,normRes);
		tripOut << "Set pMin = pNow = " << pMin << '\n';
	} else {
		pMax = pNow;
		iterHist[1] = PRpair(pMax,normRes);
		tripOut << "Set pMax = pNew = " << pMax << '\n';
	}
	if ((pNew>pMin)&&(pNew<pMax)) {
		return pNew;
	}
	dualOut << "pNew is adjusted to (minP+maxP)/2 = " << (pMin+pMax)/2.0 << '\n';
//	return pNew;
	return (pMin+pMax)/2.0;
}

void FluidCal::updatePriInjPressureHighOrder				(	const unsigned		timeStep)
{
	dualOut << "Adjusting primary injection pressure (high order interpolate)..." << '\n';
	if (std::fabs(normRes)>q_tolerance) {
		double pNow = getPriInjP();
		double pNew = highOrderPredict(pNow,normRes,-1);
		tripOut << " pNew high order = " << pNew << '\n';
		dualOut << "pNow = " << pNow;
		pNew = priInjPressureAdjust(pNow,pNew);
		double pUpdated = updateP(pNew);
		//Update injection pressure (only valid for single well injection)
//		for (unsigned i=0; i<priINodeList.size(); i++) {
//			priINodeList[i].p = pNew;
//		}
		dualOut << " normRes = " << normRes << " Injection pressure becomes = " << pUpdated << '\n';
	} else {
		highOrderPredict(0.0,0.0,timeStep);
	}
}

double FluidCal::highOrderPredict		(	const double	pNow,
											const double	rNow,
											const int		timeStep)
{
	unsigned s;
	if ((std::fabs(iterHist[0].r) < std::fabs(iterHist[1].r))) {
		s = 0;
	} else {
		s = 1;
	}
	double old_p1 = iterHist[s%2].p;
	double old_p2 = iterHist[(s+1)%2].p;
	double old_r1 = iterHist[s%2].r;
	double old_r2 = iterHist[(s+1)%2].r;
	double secant = (rNow - old_r1)/(pNow - old_p1);
	double pNew = pNow - rNow/secant;
	double p1p2 = old_p1 - old_p2;
	double p0p2 = pNow - old_p2;
	double p0p1 = pNow - old_p1;
	// First derivative of p using backward 3 points
	double d1 	= (rNow*(2*p0p1+p1p2)*(p1p2)-old_r1*(p0p2*p0p2)+old_r2*(p0p1*p0p1))/(p0p1*p1p2*p0p2);
//		double d1 	= (rNow - old_r1)/(pNow - old_p1);
	// Second derivative using backward 3 points
	double d2	= 2.0*old_r2/(p1p2*p0p2)-2.0*old_r1/(p0p1*p1p2)+2.0*rNow/(p0p1*p0p2);
	old_p2 = old_p1;
	old_p1 = pNow;
	old_r2 = old_r1;
	old_r1 = rNow;
	pNew = pNow - rNow/d1*(1+rNow*d2/(2.0*d1*d1));
//	*p_file << ' ' << d1 << ' ' << d2 << ' ' << pNew << '\n';
	if ((pNew>pMax)||(pNew<pMin)) {
		tripOut << "High order predict pNew = " << pNew << " is out of range, "
				<< "try 3 point secant method. ";
		pNew = pNow - rNow/d1;
		tripOut << "Now, pNew = " << pNew << '\n';
		if ((pNew>pMax)||(pNew<pMin)) {
			tripOut << "3 point secant pNew = " << pNew << " is out of range, "
					<< "try ordinary secant method" << '\n';
			pNew = pNow - rNow/secant;
			tripOut << "Now, pNew = " << pNew << '\n';
		}
	}
//	cnt++;
	return pNew;
//		return pNow - rNow/d1;
}

double FluidCal::linearPredict			(	const double	pNow,
											const double	rNow)
{
	static double old_p1 = 0.0;
	static double old_r1 = 1.0;
	double d1 	= (rNow - old_r1)/(pNow - old_p1);
	old_p1 = pNow;
	old_r1 = rNow;
	return pNow - rNow/d1;
}

double FluidCal::linearPredict			()
{
//	secant = (rNow - old_r1)/(pNow - old_p1);
	double secant = (iterHist[1].r - iterHist[0].r)/(iterHist[1].p - iterHist[0].p);
	return iterHist[1].p - iterHist[1].r/secant;
}

void FluidCal::logRes			(	const unsigned		step,
									const double		nowP,
									const double		newP,
									const double		normRes)
{
	char fileName[255];
	sprintf(fileName,"%s/%sfluidRes%04d.vtk",OutputSubFolder,OutputFilePrefix,step);
	std::ofstream file(fileName, std::ios::out | std::ios::app);
	file << step << ' ' << nowP << ' ' << newP << ' ' << normRes << '\n';
}

template <typename T>
void FluidCal::log				(	std::ostream*	p_file,
										const T			data)
{
	*p_file << ' ' << data;
}

bool FluidCal::serialSolve (	const unsigned	minIter,
                                const unsigned	maxIter,
                                const double 	precision)
{
    Clock	sClock("PCG Serial");
    Eigen::VectorXd r = q-H*p;
    Eigen::VectorXd m = getPreCondJacobi();
    Eigen::VectorXd d = m.cwiseProduct(r);
    double newDelta;
    double init_delta = newDelta = d.dot(r);
    dualOut << "gIteration starts... precision*init_delta =" << std::max(precision*init_delta,precision) <<'\n';
    double 	alpha,beta;
    double	oldDelta;
    Eigen::VectorXd qq(q.size()), s(q.size());
    unsigned i = 0;
    while (((newDelta > fabs(precision*precision*init_delta))||(i<minIter))&&(i<maxIter))
    {
        qq = H*d;
        alpha = newDelta/d.dot(qq);
        p += d*alpha;
        r -= qq*alpha;
        s = m.cwiseProduct(r);
        oldDelta = newDelta;
        newDelta = r.dot(s);
        beta = newDelta / oldDelta;
        d = s + beta*d;
        i++;
    }
    sClock.get();
    double convergence = newDelta / precision/init_delta;
    dualOut << "Iteration cycle = " << i << " new_delta / precision*init_delta = " << convergence << '\n';
    if (convergence > 50.0) {
    	errOut << "Sereve divergence, calculation stop!"<< '\n';
        return false;
    }
    return true;
}

bool FluidCal::useEigenCGSolver	(	unsigned		maxIteration,
                                    double			precision)
{
    using namespace Eigen;
    Clock	sClock;
    ConjugateGradient<SpMat,Lower,DiagonalPreconditioner<double> >	ecg;
    ecg.setMaxIterations(maxIteration);
    ecg.setTolerance(precision);
    sClock.start("EigenCGSolver");
    ecg.compute(H);
    p = ecg.solve(q);
    sClock.get();

    dualOut << "Iteration No = " 		<< ecg.iterations() << '\n';
    dualOut << "Estimated error = " 	<< ecg.error() << '\n';

    if (ecg.error()>50*sqrt(precision))
    {
        return false;
    }
    else
    {
        return true;
    }
}

bool FluidCal::sparseCholeskySolve ()
{
	Clock clock("sparseCholeskySolve");
	Eigen::SimplicialCholesky<SpMat>		sCholesky(H);
	p = sCholesky.solve(q);
	clock.get();
//	std::cout << "sCholesky.info() = " << sCholesky.info() << '\n';
//	std::cout << "(sCholesky.info()==Eigen::Success) = " << (bool (sCholesky.info()==Eigen::Success)) << '\n';
	return (sCholesky.info()==Eigen::Success);
}

Eigen::VectorXd FluidCal::getPreCondJacobi	()
{
	Eigen::VectorXd		m;
    m.resize(calNodeNum);
    for (unsigned DOF=0; DOF<calNodeNum; DOF++) {
    	m[DOF] = 1.0/H.coeff(DOF,DOF);
    }
    return m;
}

bool FluidCal::fillH	()
{
	using Eigen::VectorXd;
	std::cout << "Filling fluid matrix..."<< '\n';
	H.resize(0,0);
	H.resize(calNodeNum,calNodeNum);
	H.reserve(VectorXd::Constant(calNodeNum,maxCoordNo));
//	tripOut << H << '\n';
	unsigned fNodeID,nbDOF,nbFNodeID,nbNum;
	double	hij,sum_hij=0.0;
	std::vector<PriINode>::iterator		it;
	for (unsigned DOF=0; DOF<DOFseg1; DOF++) {
		fNodeID 	= DOFtoFNode[DOF];
		nbNum 		= fNodeList[fNodeID].nbActive.size();
		for (unsigned k=0; k<nbNum; k++) {
//			tripOut << H << '\n';
			nbFNodeID = fNodeList[fNodeID].nbActive[k].fNodeID;
			if (conFNode.find(fNodeID)!=conFNode.end()) {
				hij = getHij(fNodeList[fNodeID].nbActive[k].pipeID);
//				tripOut << hij << '|';
				H.coeffRef(DOF,DOF) 		+= hij;
				sum_hij +=hij;
				//To handle the case where the nbFNode is a primary injection node
				it = std::find(priINodeList.begin(),priINodeList.end(),nbFNodeID);
				if (it==priINodeList.end()) {
					nbDOF = fNodeToDOF[nbFNodeID];
//					tripOut << nbDOF << ',' << hij << ',';
					if (nbDOF<calNodeNum) {
						H.coeffRef(DOF,nbDOF)		-= hij;
						sum_hij -=hij;
					}
				} else {
					q[DOF] += hij*priINodeList[it-priINodeList.begin()].p;
				}
			}
		}
	}
	for (unsigned DOF=DOFseg1; DOF<calNodeNum; DOF++) {
		fNodeID 	= DOFtoFNode[DOF];
		nbNum 		= fNodeList[fNodeID].nbActive.size();
		for (unsigned k=0; k<nbNum; k++) {
//			if (activeConFNode.find(fNodeID)!=activeConFNode.end()) {
			nbDOF = fNodeToDOF[fNodeList[fNodeID].nbActive[k].fNodeID];
			if (nbDOF<calNodeNum) {
//				tripOut << nbDOF << '|';
				hij = getHij(fNodeList[fNodeID].nbActive[k].pipeID);
//				tripOut << hij << '|';
//				tripOut << H << '\n';
				H.coeffRef(DOF,DOF) 		+= hij;
				H.coeffRef(DOF,nbDOF)		-= hij;
				sum_hij +=hij;
//				tripOut << H << '\n';
			}
		}
	}
	if (sum_hij<Tiny*Tiny*Tiny) {
		tripOut << "The permeability of pipes are too low, impossible to carry out fluid calculation!" << '\n';
//		tripOut << "sum_hij = " << sum_hij << '\n';
		return false;
	}
	H.makeCompressed();
	std::cout << "Finish filling fluid matrix..."<< '\n';
	return true;
}

double FluidCal::getHij			(	unsigned						pipeID)
{
	GLatForce lforce;
	unsigned LatID1 = fNodeList[pipeList[pipeID].nbFNodeID[0]].LatticeID;
	unsigned LatID2 = fNodeList[pipeList[pipeID].nbFNodeID[1]].LatticeID;
	if (ProblemID==2) {
        if ((std::binary_search(initCrackList.begin(),initCrackList.end(),LatID1))||
                (std::binary_search(initCrackList.begin(),initCrackList.end(),LatID2))) {
            return Huge;
        }
	}
	double apecture1 = lforce.getCrackOpening(LatID1);
	double apecture2 = lforce.getCrackOpening(LatID2);
	if ((apecture1>minApecture)&&(apecture2>minApecture)) {
		return pipeList[pipeID].width/(12.0*viscosity*
				(	pipeList[pipeID].halfLength[0]/(apecture1*apecture1*apecture1)+
					pipeList[pipeID].halfLength[1]/(apecture2*apecture2*apecture2)));
	} else {
		return 0.0;
	}
}

std::vector<IDAndInfo>	FluidCal::getIDAndPressure	()
{
	std::vector<IDAndInfo>		out;
	out.resize(fNodeList.size());
	unsigned fNodeID;
	for (fNodeID=0; fNodeID<fNodeList.size(); fNodeID++) {
		out[fNodeID].first 	= fNodeList[fNodeID].LatticeID;
		out[fNodeID].second = 0.0;
	}
	for (unsigned DOF=0; DOF<p.size(); DOF++) {
		fNodeID = DOFtoFNode[DOF];
		out[fNodeID].second = std::max(p[DOF],0.0);
	}
	for (unsigned i=0; i<priINodeList.size(); i++) {
		fNodeID = priINodeList[i].fNodeID;
		out[fNodeID].second = std::max(priINodeList[i].p,0.0);
	}
	/*
	for (std::set<unsigned>::iterator it = activeConFNode.begin(); it != activeConFNode.end(); ++it) {
		fNodeID = *it;

	}
	*/
	/*
	for (fNodeID=0; fNodeID<fNodeList.size(); fNodeID++) {
		out[fNodeID].first 	= fNodeList[fNodeID].LatticeID;
		out[fNodeID].second = getPriInjP();
	}
	*/
	return out;
}

std::vector<unsigned>   FluidCal::getLatID  ()
{
    std::vector<unsigned>   latList;
    for (unsigned fNodeID = 0; fNodeID<fNodeList.size(); fNodeID++) {
        latList.push_back(fNodeList[fNodeID].LatticeID);
    }
    return latList;
}

bool	FluidCal::updateActiveConFNode		()
{
	bool isChanged = false;
	unsigned i = 0;
	static unsigned acc = 0;
	for (unsigned DOF=0; DOF<DOFtoFNode.size(); DOF++) {
		if (p[DOF]<0.0) {
//			std::cout << p[DOF] << ' ';
			setInactiveFNode(fNodeList[DOFtoFNode[DOF]].LatticeID);
//			activeConFNode.erase(DOFtoFNode[DOF]);
			isChanged = true;
			i++;
		}
	}
	acc+=i;
	dualOut << "No of conFNode become inactive in this step = " << i << " accumlated inactive conFNode = " << acc << '\n';
	if (i==0) {
		acc = 0;
	} else {
		connectedFNodeSet();
	}
	return isChanged;
}

std::vector<double>	FluidCal::getPressure	(	const double	dummyValue)
{
	std::vector<double>		out;
	out.resize(fNodeList.size(),dummyValue);
	unsigned fNodeID;
	if (!DOFtoFNode.empty()) {
		for (unsigned DOF=0; DOF<calNodeNum; DOF++) {
			fNodeID = DOFtoFNode[DOF];
//			out[fNodeID] = fNodeList[fNodeID].old_p + p[DOF];
			out[fNodeID] = p[DOF];
		}
	}
	for (unsigned i=0; i<priINodeList.size(); i++) {
		fNodeID = priINodeList[i].fNodeID;
//		out[fNodeID] = fNodeList[fNodeID].old_p + priINodeList[i].p;
		out[fNodeID] = priINodeList[i].p;
	}
	return out;
}

std::vector<double> FluidCal::getLeakOff   ()
{
    std::vector<double>     out;
    out.resize(fNodeList.size(),0.0);
    unsigned fNodeID;
    for (unsigned i=0; i<fNodeList.size(); i++) {
        out[i] = fNodeList[i].leakVol;
    }
    return out;
}

double FluidCal::getPriInjP()
{
	double pPri =0.0;
	for (unsigned i=0; i<priINodeList.size(); i++) {
		pPri += priINodeList[i].p;
	}
	return pPri/priINodeList.size();
}

std::vector<double>	FluidCal::getFlowRate	()
{
	std::vector<double>		out;
	out.resize(fNodeList.size(),0.0);
	if (!DOFtoFNode.empty()) {
		for (unsigned DOF=0; DOF<calNodeNum; DOF++) {
			out[DOFtoFNode[DOF]] = q[DOF];
		}
	}
	for (unsigned i = 0; i< priINodeList.size(); i++) {
		out[priINodeList[i].fNodeID] += priINodeList[i].qin;
	}
	return out;
}

double  FluidCal::getResidual ()
{
	Eigen::VectorXd res = H*p-q;
	return res.dot(res)/p.size();
}

void FluidCal::logPQ				(	const unsigned				step,
										const std::vector<double>	P,
										const std::vector<double>	Q)
{
	char fileName[255];
	sprintf(fileName,"%s/%sfPQ%04d.vtk",OutputSubFolder,OutputFilePrefix,step);
	std::ofstream file(fileName, std::ios::out | std::ios::app);
	for (unsigned i=0; i<P.size(); i++) {
		file << P[i] << ' ' << Q[i] << '\n';
	}
}

void FluidCal::printVectors	(	    const unsigned 		step,
									const bool 			isPrintp,
									const bool 			isPrintq,
									const bool 			isPrintH)
{
	char fileName[255];
	sprintf(fileName,"%s/%sFluidVecs%04d.vtk",OutputSubFolder,OutputFilePrefix,step);
	std::ofstream file(fileName, std::ios::out | std::ios::app);
	if (isPrintp) {
		file << "p = " << '\n' << p << '\n';
	}
	if (isPrintq) {
		file << "q = " << '\n' << q << '\n';
	}
	if (isPrintH) {
		file << "H = " << '\n' << H << '\n';
	}
}
