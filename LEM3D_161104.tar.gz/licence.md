Copyright (C) Kam Wing (John) Wong - All Rights Reserved

Unauthorized copying of this file, via any medium is strictly prohibited without written consent of Kam Wing (John) Wong

Proprietary and confidential

Written by Kam Wing Wong <civil.john@gmail.com>, <kwjw2@cam.ac.uk>, October 2013
 
 Declaration of Contributions
 
 This code is procduced for the implementation of Hydraulic Fracturing simulation by Lattice Element Method (LEM), a PhD project at
 University of Cambridge funded by EPSRC Industry-CASE Award and HKIE Young Engineers Arthur and Louise May Memorial Scholarship.
 
 This code is sololy rewritten and tested by Kam Wing (John) Wong.
 
 The research is supervised by Prof. Kenichi Soga. The idea of LEM is introduced by Dr Jean-Yves Delenne at University of 
 University of montpellier II. Dr Xiaomin Xu has contributed the very early stage of LEM development with a brief C++ code
 .Dr. Krishna has helped to set up Linux platform for running the code and various IT issues and attebd regular research meetings
 in the past 2 years.
 
